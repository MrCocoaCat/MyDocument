sh clear.sh
sh del_br.sh
sh del_dnsmasq.sh
sh nsp_del.sh

