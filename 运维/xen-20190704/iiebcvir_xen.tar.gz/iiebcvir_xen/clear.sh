#!/bin/sh
echo "Cleaning Start.....";
for record in $(sudo virsh  list | grep -E '(windows|linux|router|IDS|IPS|FIRE|ROU)' | awk '{print $1}')
do
	sudo virsh destroy $record;
done

for record in $(ovs-vsctl show | grep Bridge | grep "ovsbr" | awk '{print $2}' | sed 's/\"//g')
do
	sudo ovs-vsctl del-br $record;
done


for record in $(ovs-vsctl list-ports nuca_br | grep nuca_br_)
do
	sudo ovs-vsctl del-port $record;
done

echo "Cleaning VNC.....";
kill -9 $(ps -ef|grep launch.sh | grep vnc | awk '{print $2}');


echo "Cleaning End              [OK]";

