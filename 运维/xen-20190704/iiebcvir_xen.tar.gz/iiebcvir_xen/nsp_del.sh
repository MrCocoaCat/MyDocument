for record in $(ip netns list | awk -F " " '{print $1}')
do
       sudo ip netns delete  $record;
           done
