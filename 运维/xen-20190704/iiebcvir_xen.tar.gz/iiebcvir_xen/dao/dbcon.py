# -*-coding:utf-8-*-
import pymysql
from DBUtils.PooledDB import PooledDB
from logger.logger import *
from conf.config import ConfParser

conf = ConfParser()

class DB(object):
    """docstring for DbConnection"""
    __pool = None

    def __init__(self):
        self.pool = DB.__get_conn()
        self.conn = None
        self.cursor = None

    @staticmethod
    def __get_conn():
        if DB.__pool is None:
            try:
                DB.__pool = PooledDB(creator=pymysql, host=conf.get("DB", "host"),port=int(conf.get("DB","port")),user=conf.get("DB","user"),passwd=conf.get("DB","passwd"),db=conf.get("DB","db"),charset=conf.get("DB","charset"))
            except Exception, e:
                logging.error("%s : %s" % (Exception,e))
        return DB.__pool

    def connect(self, cursor=pymysql.cursors.DictCursor):
        self.conn = self.pool.connection()
        self.cursor = self.conn.cursor(cursor=cursor)
        return self.cursor

    def query_sql(self, sql):
        self.cursor.execute(sql)
        result = self.cursor.fetchall()
        return result

    def execute_sql(self, sql):
        self.cursor.execute(sql)
        self.conn.commit()
        result = self.cursor.lastrowid
        return result

    def update_sql(self, sql):
        result = self.cursor.execute(sql)
        self.conn.commit()
        return result

    def close(self):
        self.cursor.close()
        self.conn.close()