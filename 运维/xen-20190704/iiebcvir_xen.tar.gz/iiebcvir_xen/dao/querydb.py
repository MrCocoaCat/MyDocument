# -*-coding:utf-8-*-

from entity.data import *
from dao.dbcon import DB
from logger.logger import *

globala = []
db = DB()

#对数据库的各种操作
class QueryDB(object):

    def __init__(self):
        pass

    #查询Int型结果，sqlStr查询数据库的结果是一个整数，需要做sql查询结果空值的判断
    def queryint(self,res):
        try:
            if len(res) == 0:
                return 0
            elif len(res) == 1:
                return res
            else:
                return res[0]
        except TypeError:
            logging.error('error:type error')
            return -1

    #初始化虚拟机模板相关信息，保存在全局数据结构中
    def initVMTemplateInfo(self):
        global globala
        db.connect()
        sql = 'SELECT * FROM `b_vm_template`;'
        globala = db.query_sql(sql)
        db.close()
        return globala

    #修改Case状态为正在运行  运行状态为'200503'，返回受影响的行数
    def updataCaseStateRunning(self, caseid):
        db.connect()
        sql = "UPDATE `b_case` SET state = '200503' WHERE case_id = '%s';" % caseid
        res = db.update_sql(sql)
        db.close()
        return res

    #取得node_id节点基础节点硬盘镜像文件路径
    def getBaseNodeDiskImgFile(self, node_id):
        db.connect()
        sql = "SELECT diskimg_file From `b_node` WHERE node_id = %d;" % node_id
        res = db.query_sql(sql)
        db.close()
        return res[0]['diskimg_file']

    #取得当前服务器内存总大小
    def getLocalMachineMemorySize(self, ip):
        db.connect()
        sql = "SELECT memory FROM `b_machine` WHERE discription = '%s';" % ip
        res_list = db.query_sql(sql)
        res = self.queryint(res_list)
        db.close()
        print res

    #根据模板ID获得模板信息
    def getVMTemplate(self, templateId):
        db.connect()
        sql = "SELECT file_path FROM `b_vm_template` WHERE id = %d;" % templateId
        result = db.query_sql(sql)
        if result is ():
            path = None
        else:
            path = result[0]["file_path"]
        db.close()
        return path

    #保存Guest相关信息到数据库， vnc_ip， vnc_port， node_b_name， diskimg_file， real_template_id
    def saveVGuestInfo(self,VGuest):
        db.connect()
        sql = "UPDATE `b_node` SET vnc_ip='%s', vnc_port=%d, node_b_name='%s', diskimg_file='%s' WHERE node_id=%d;" % (VGuest.vncIp, VGuest.vncPort, VGuest.nodeBName, VGuest.diskimgFile,  VGuest.id)
        print sql
        res = db.update_sql(sql)
        logging.info("%s load into table b_node successfully" % VGuest.nodeBName)
        print res
        db.close()
        return res

    #保存Router相关信息到数据库，node_b_name，diskimg_file，real_template_id
    def saveVRouterInfo(self, VRouter):
        db.connect()
        sql = "UPDATE `b_node` SET node_b_name='%s', diskimg_file='%s' AND real_template_id=%d WHERE node_id=%d;" % (VRouter.node_b_name, VRouter.diskimg_file, VRouter.real_template_id, VRouter.id)
        res = db.update_sql(sql)
        db.close()
        return res

    #保存Switch相关信息到数据库，node_b_name
    def saveVSwitchInfo(self, VSwitch):
        db.connect()
        sql = "UPDATE `b_node` SET node_b_name = '%s' WHERE node_id=%d;" % (VSwitch.ovsbr_name, VSwitch.id)
        res = db.update_sql(sql)
        db.close()
        return res
    def GetVSwitchName(self,VSwitchId):
        db.connect()
        sql = "SELECT node_b_name from `b_node` WHERE node_id=%d" % (VSwitchId)
        res = db.query_sql(sql)
        db.close()
        return res

    def GetBbaseID(self,node_id):
        db.connect()
        sql = "select base_node_id from b_node where node_id = %d" %(node_id)
        res = db.query_sql(sql)
        db.close()
        return res
    #保存IPS相关信息到数据库，node_b_name，diskimg_file，real_template_id
    #IDS、防火墙、专用路由与此类似
    def saveVIPSInfo(self, VIps):
        db.connect()
        sql = "UPDATE `b_node` SET node_b_name='%s', diskimg_file='%s' AND real_template_id= %d WHERE node_id=%d;" % (VIps.node_b_name, VIps.diskimg_file, VIps.real_template_id, VIps.id)
        res = db.update_sql(sql)
        db.close()
        return res


    #查询模板的镜像文件地址，real_template_id
    def getRealTemplateId(self, nodeId):
        db.connect()
        sql = "SELECT real_template_id FROM `b_node` WHERE node_id = %d;" % nodeId
        res = db.query_sql(sql)
        db.close()
        return res[0]['real_template_id']

    #查询子节点也就是二级模板的硬盘镜像
    def getSonNodeDiskFile(self, nodeId):
        db.connect()
        sql = "select diskimg_file from b_node where node_id = (select base_node_id from b_node  where node_id = %d);" % nodeId
        print sql
        res = db.query_sql(sql)
        db.close()
        return res[0]['diskimg_file']

    #修改b_node_transfer_file
    def updateNodeTransferFile(self, nodeID, state):
        db.connect()
        sql = "UPDATE `b_node_transfer_file` SET state = %d WHERE node_id = %d ;" % (state, nodeID)
        res = db.update_sql(sql)
        db.close()
        return res


    #删除b_node_transfer_file
    def deleteNodeTransferFile(self, caseId, nodeId):
        db.connect()
        sql = "DELETE * FROM `b_node_transfer_file` WHERE node_id = %d AND case_id = '%s';" % (nodeId, caseId)
        res = db.update_sql(sql)
        db.close()
        return res

    #查询b_node_transfer_file
    def selectNodeTransferFile(self, caseId, nodeId):
        db.connect()
        sql = "SELECT * FROM `b_node_transfer_file` WHERE node_id = %d AND case_id = %s;" % (nodeId, caseId)
        res = db.query_sql(sql)
        db.close()
        return res

    # 通过查询caseid来查询相应的名字
    def selectNodename(self, caseid):
        db.connect()
        sql = "SELECT b_node.node_b_name from b_node LEFT JOIN b_topological_structure on b_node.topological_id= b_topological_structure.topological_id where b_topological_structure.case_id=%d" % caseid
        res = db.query_sql(sql)
        db.close()
        return res
    def GetNodeBName(self, nodeid):
        db.connect()
        sql = "SELECT node_b_name from b_node  where node_id=%d" % nodeid
        res = db.query_sql(sql)
        db.close()
        return res