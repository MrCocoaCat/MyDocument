# -*-coding:utf-8-*-
from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from basecls import Base
from entity.feedback import FeedBack


class StartCls(Base):
    def __init__(self):
        pass

    def action(self,message):
        try:
            messagedata = json.loads(message)
        # casedatatmp =CaseData()
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
        feedback = FeedBack()
        feedback.taskid = messagedata["taskid"]
        feedback.name = "START"
        feedback.server_ip = messagedata["server_ip"]
        caseid = messagedata["caseid"]
        feedback.conclusion = 1
        feedback.emessage = "all will start"
        feedback.feed_back("EMU2MCUMessageTopic")
