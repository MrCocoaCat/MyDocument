from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from basecls import Base
from util.diskopration import *
import os
from entity.feedback import FeedBack

class FileCancle(Base):

    def __init__(self):
        pass

    def action(self, message):
        conf = ConfParser()
        msg_data = json.loads(message)
        id = int(msg_data["taskid"])
        localip = conf.get("EMU","ServerLocalIP")
        ipaddr = localip
        name = msg_data["name"]
        conclusion = 1
        dbqueryobj = QueryDB()
        CaseId = msg_data["caseid"]
        node_id = msg_data["node_id"]
        basedir = conf.get("EMU","CaseFilePath")
        fulldir = basedir + CaseId + "/"
        fullimgdir = fulldir + "diskfile/"
        if not os.path.exists(fullimgdir):
            os.makedirs(fullimgdir)

        uploadimgpath = fullimgdir + str(node_id) + ".img"
        conclusion = 1
        if conclusion == 1:
            print node_id
            print dbqueryobj.selectNodename(int(node_id))
            ins_name = dbqueryobj.GetNodeBName(int(node_id))[0]["node_b_name"]
            cmd = "virsh detach-disk %s  %s" % (ins_name,uploadimgpath)
            os.popen(cmd)

        feedback = FeedBack()
        feedback.taskid = msg_data["taskid"]
        feedback.server_ip = localip
        feedback.name = msg_data["name"]
        feedback.conclusion = conclusion
        feedback.emessage = "file transfer"
        feedback.feed_back("EMU_KVM2MCUMessageTopic")