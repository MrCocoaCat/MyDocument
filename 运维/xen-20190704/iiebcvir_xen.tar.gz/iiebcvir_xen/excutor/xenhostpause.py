# -*-coding:utf-8-*-
from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from entity.feedback import FeedBack


class PauseCls(object):

    def __init__(self):
        pass

    def action(self,message):
        try:
            messagedata = json.loads(message)
        # casedatatmp =CaseData()
        except Exception,e:
            logging.error("%s : %s" % (Exception, e))
        feedback = FeedBack()
        feedback.taskid = messagedata["taskid"]
        feedback.name = messagedata["name"]
        feedback.server_ip = messagedata["server_ip"]
        caseid = messagedata["caseid"]
        feedback.conclusion = 1
        feedback.emessage = "all paused "
        feedback.feed_back("EMU2MCUMessageTopic")
        caseid = messagedata["caseid"]
        caseid = int(caseid)
        dbqueryobj = QueryDB()
        #1. 创建网桥
        vir_hosts = dbqueryobj.selectNodename(caseid)
        vir_manager = virtualmanager()
        for vir_host in vir_hosts:
            try:
                # vir_manager.vir_pause(vir_host["node_b_name"])
                os.popen("virsh pause %s" % vir_host["node_b_name"])
            except Exception, e:
                logging.info("%s : %s" % (Exception, e))
