# -*-coding:utf-8-*-
from excutor.xenhostdeploy import Deploycls
from excutor.xenhostclose import CloseCls
from excutor.xenhostpause import PauseCls
from excutor.xenhostreboot import RebootCls
from excutor.xenhostresume import ResumeCls
from excutor.hoststart import StartCls
from excutor.heartbeat import HeartBeat
from excutor.filetransfer import FileTransfer
from excutor.filecancle import FileCancle


class ActionFactory(object):

    def getfactory(self, operation):
        operation = operation.encode("utf-8")

        if operation == 'DEPLOY':
            print operation
            return Deploycls()
        elif operation == "REBOOT":
            return RebootCls()
        elif operation == 'START':
            return StartCls()
        elif operation == "CLOSE":
            return CloseCls()
        elif operation == "UNPAUSE":
            return ResumeCls()
        elif operation == "PAUSE":
            return PauseCls()
        elif operation == "heartbeat":
            return HeartBeat()
        elif operation == "FILE_TRANSFER":
            return FileTransfer()
        elif operation == "FILE_TRANSFER_CANCEL":
            return FileCancle()
        else:
            return None
