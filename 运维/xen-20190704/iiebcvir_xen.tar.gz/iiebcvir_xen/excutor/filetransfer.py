from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from basecls import Base
from util.diskopration import *
import os
import locale
from entity.feedback import FeedBack
import re

class FileTransfer(Base):

    def __init__(self):
        pass

    def action(self, message):
        conf = ConfParser()
        msg_data = json.loads(message)
        id = int(msg_data["taskid"])
        localip = conf.get("EMU","ServerLocalIP")
        ipaddr = localip
        name = msg_data["name"]
        is_upload = msg_data["is_upload"]
        conclusion = 1
        dbqueryobj = QueryDB()
        CaseId = msg_data["caseid"]
        host_file = conf.get("EMU","XMLFilePathPre") + msg_data["define"]["host_file"]
        host_file = host_file.encode(locale.getdefaultlocale()[1])
        node_id = msg_data["node_id"]
        basedir = conf.get("EMU","CaseFilePath")
        fulldir = basedir + CaseId + "/"
        fullimgdir = fulldir + "diskfile/"
        if not os.path.exists(fullimgdir):
            os.makedirs(fullimgdir)

        uploadimgpath = fullimgdir + str(node_id) + ".img"
        ins_name = dbqueryobj.GetNodeBName(int(node_id))[0]["node_b_name"]
        if re.search("window",ins_name) is not None:
            if os.path.exists(uploadimgpath) is False:
                os.popen("cp /home/iievirimg/attempt/1024.img %s" % uploadimgpath)
                logging.info("cp /home/iievirimg/attempt/1024.img %s" % uploadimgpath)
        disk_operation = DiskOperation()
        if int(is_upload) == 1:
            uploadfile = "/" + host_file.split("/")[-1]
            uploadfile = unicode(uploadfile, "utf-8")
            uploadfile = uploadfile.encode(locale.getdefaultlocale()[1])
            if os.path.exists(uploadimgpath):
                ins_name = dbqueryobj.GetNodeBName(int(node_id))[0]["node_b_name"]
                try:
                    cmd = "virsh detach-disk %s  %s" % (ins_name,uploadimgpath)
                    os.popen(cmd)
                except Exception, e:
                    logging.info("%s : %s" % (Exception, e))
                status = disk_operation.upload_disk(uploadimgpath, host_file, uploadfile)
            else:
                status = disk_operation.create_disk(uploadimgpath, host_file, uploadfile)
            if status is 0:
                logging.info("the file upload success")
                dbqueryobj.updateNodeTransferFile(node_id,2)
            elif status is 1:
                conclusion = -1
        print dbqueryobj.GetNodeBName(int(node_id))

        cmd = "virsh attach-disk %s  '%s' 'vda' --live --driver 'qemu' --subdriver 'qcow2'  --targetbus 'virtio'" % (ins_name, uploadimgpath)
        print cmd
        os.popen(cmd)


        feedback = FeedBack()
        feedback.taskid = msg_data["taskid"]
        feedback.server_ip = localip
        feedback.name = msg_data["name"]
        feedback.conclusion = conclusion
        feedback.emessage = "file transfer"
        feedback.feed_back("EMU_KVM2MCUMessageTopic")






