from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from basecls import Base
from entity.heartback import HeartBack


class HeartBeat(Base):

    def __init__(self):
        pass

    def action(self, message):
        conf = ConfParser()
        heartback = HeartBack()
        msg_data = json.loads(message)
        heartback.id = int(msg_data["id"])
        localip = conf.get("EMU","ServerLocalIP")
        heartback.ipaddr = localip
        heartback.name = msg_data["name"]
        heartback.feed_back("BACKEND2MCU_ALIVE")

