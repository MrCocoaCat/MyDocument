# -*-coding:utf-8-*-

class Base(object):
    def __init__(self):
        pass

    def action(self):
        pass