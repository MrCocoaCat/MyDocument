# -*-coding:utf-8-*-
from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from xmlparse.nodeinfo import *
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from entity.feedback import FeedBack
from basecls import Base
from util.routing_format import *
from util.fileupload import FileOperations
from assignip.assignip import AssignIp
from entity.subnet import Subnet
from task.firewallcreate import *
from task.idscreate import *
from task.inscreate import *
from task.ipscreate import *
from task.ovscreate import *
from task.routercreate import *



class Deploycls(Base):

    def __init__(self):
        pass

    def action(self,message):
        # first receive the message
        logging.debug("%s" %message)
        # second analyse the message
        try:
            messagedata = json.loads(message)
        except Exception,e:
            logging.error("%s : %s" % (Exception, e))
        # 获取配置文件信息
        conf = ConfParser()
        # 获取拓扑文件完整路径
        path = messagedata["define"]["tfile"]
        path = conf.get("EMU", "XMLFilePathPre") + path
        # 生成feedback实例用来收集feedback信息，最终发出信息
        feedback = FeedBack()
        feedback.taskid = messagedata["taskid"]
        feedback.name = messagedata["name"]
        feedback.server_ip = messagedata["server_ip"]
        errmsg = ""
        conclusion = -1
        # 生成casedata实例信息，用于存放解析完成的数据
        case_data = CaseData()
        xml_parse = XmlParser()
        res = xml_parse.parse_xml(path,case_data)
        dbqueryobj = QueryDB()

        # 根据拓扑结构创建普通的网桥信息
        common_ovs_create(case_data,dbqueryobj)

        # 根据拓扑结构创建隐藏的网桥信息
        hidden_ovs_create(case_data)

        # 启动相应的分配IP的程序
        subnet_assign(xml_parse, path, case_data)

        # 创建主机实例
        instance_create(case_data,conf,messagedata,virtualmanager,dbqueryobj)

        # 创建路由实例
        router_create(case_data,conf,messagedata,virtualmanager,dbqueryobj)

        # 创建ips
        ips_create(case_data,conf,messagedata,virtualmanager,dbqueryobj)

        # 创建ids
        ids_create(case_data,conf,messagedata,virtualmanager,dbqueryobj)

        # 创建firewall
        firewall_create(case_data,conf,messagedata,virtualmanager,dbqueryobj)