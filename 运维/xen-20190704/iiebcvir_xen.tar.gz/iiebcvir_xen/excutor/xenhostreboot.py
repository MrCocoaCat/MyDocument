# -*-coding:utf-8-*-
from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from entity.feedback import FeedBack
from basecls import Base
from util.routing_format import *
from util.fileupload import FileOperations
from assignip.assignip import AssignIp
from entity.subnet import Subnet
from util.sprouterfile import *
import re

class RebootCls(Base):
    def __init__(self):
        pass

    def action(self,message):
        logging.debug("%s" % message)
        # second analyse the message
        try:
            messagedata = json.loads(message)
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
        # 获取配置文件信息
        conf = ConfParser()
        # 获取拓扑文件完整路径
        path = messagedata["define"]["tfile"]
        path = conf.get("EMU", "XMLFilePathPre") + path
        # 生成feedback实例用来收集feedback信息，最终发出信息
        feedback = FeedBack()
        feedback.taskid = messagedata["taskid"]
        feedback.name = messagedata["name"]
        feedback.server_ip = messagedata["server_ip"]
        errmsg = ""
        IsTemplate = messagedata["is_template"]
        conclusion = 1
        need = 0
        done = 0
        # 生成casedata实例信息，用于存放解析完成的数据
        case_data = CaseData()
        xml_parse = XmlParser()
        res = xml_parse.parse_xml(path, case_data)
        dbqueryobj = QueryDB()

        # 1. 创建网桥  正常网桥和隐藏网桥
        switches = case_data.switch_dict
        print switches
        logging.info("br's number is %d" % len(switches))
        for k, switch in switches.items():
            if switch is not None:
                ovsname = "ovsbr" + str(getbr())
                switch.ovsbr_name = ovsname
                try:
                    os.popen("ovs-vsctl add-br %s" % switch.ovsbr_name)
                    os.popen("ifconfig %s up" % switch.ovsbr_name)

                    # add peer

                    dbqueryobj.saveVSwitchInfo(switch)
                except Exception, e:
                    logging.error("%s : %s" % (Exception, e))
                    errmsg = "br %s create failed" % switch


        for k,switch in switches.items():
            if switch is not None:
                switch_name = switch.ovsbr_name
                for link_switch in switch.linkto_emu_switch_list:
                    if link_switch is not None:
                        link_switch_name = dbqueryobj.GetVSwitchName(int(link_switch))[0]["node_b_name"]
                        switch_port = "to_" + link_switch_name
                        link_switch_port = "to_" + switch_name
                        cmd1 = "ovs-vsctl add-port %s %s" %(switch_name, switch_port)
                        cmd2 = "ovs-vsctl set interface %s type=patch" %(switch_port)
                        cmd3 = "ovs-vsctl set interface %s options:peer=%s" %(switch_port,link_switch_port)
                        cmd4 = "ovs-vsctl add-port %s %s" % (link_switch_name, link_switch_port)
                        cmd5 = "ovs-vsctl set interface %s type=patch" % (link_switch_port)
                        cmd6 = "ovs-vsctl set interface %s options:peer=%s" % (link_switch_port, switch_port)
                        print cmd1
                        print cmd2
                        print cmd3
                        print cmd4
                        print cmd5
                        print cmd6
                        logging.info("%s" % cmd1)
                        logging.info("%s" % cmd2)
                        logging.info("%s" % cmd3)
                        logging.info("%s" % cmd4)
                        logging.info("%s" % cmd5)
                        logging.info("%s" % cmd6)
                        try:
                            os.popen(cmd1)
                            os.popen(cmd2)
                            os.popen(cmd3)
                            os.popen(cmd4)
                            os.popen(cmd5)
                            os.popen(cmd6)
                        except Exception, e:
                            logging.error("%s : %s" % (Exception, e))
        hid_switches = case_data.hid_switch_dict
        logging.info("hidden br's number is %d" % len(switches))
        for k, hid_switch in hid_switches.items():
            if hid_switch is not None:
                try:
                    hid_switch.ovsbr_name = "hid" + hid_switch.ovsbr_name[0:7:]
                    os.popen("ovs-vsctl add-br %s" % hid_switch.ovsbr_name)
                    os.popen("ifconfig %s up" % hid_switch.ovsbr_name)
                    for boundary_interface in hid_switch.boundary_interface_list:
                        if int(boundary_interface.boundary) == 1:
                            if boundary_interface.p_eth is not None:
                                os.popen("ovs-vsctl add-port %s %s" % (hid_switch.ovsbr_name, boundary_interface.p_eth))
                            else:
                                logging.error("p_eth is NULL")

                except Exception, e:
                    logging.error("%s : %s" % (Exception, e))
                    errmsg = "br %s create failed" % hid_switch
                    conclusion = -1

        xml_parse.parse_xml_subnet(path, case_data)
        subnet_dict = case_data.subnet_dict
        print len(subnet_dict)

        for k, subnet in subnet_dict.items():
            print k
            print "subnet's status is:"
            print subnet.need_dhcp_server()
            if subnet.need_dhcp_server():
                res_status = subnet.start_dhcp_server()
                if res_status is 0:
                    logging.info("assign ip success")
                else:
                    logging.error("assign ip failed")

                    # 创建完所有的ovs switch之后需要重新解析xml获得subnet的信息

                    # 对case_data.subnet做循环
                    #                    if subnet.need_dhcp_server():
                    #                        subnet.start_dhcp_server()














                    # 2. 创建主机实例
        instances = case_data.virhost_dict
        basedir = conf.get("EMU", "CaseFilePath")
        CaseId = messagedata["caseid"]  # caseid
        fulldir = basedir + CaseId + "/"
        fullimgdir = fulldir + "diskfile/"
        if not os.path.exists(fullimgdir):
            os.makedirs(fullimgdir)
        instance_names = []
        vir_manager = virtualmanager()
        logging.info("virtual manager is run")

        for k, instance in instances.items():  # 获取主机实例信息，进行创建
            need = need + 1
            vm_template_path = dbqueryobj.getVMTemplate(instance.templateId)  # get template path
            print vm_template_path
            path_pre = conf.get("EMU", "TemplateImgFilePre")
            path = path_pre + vm_template_path
            name = instance.osType + "_" + str(instance.id)
            fullpath = fullimgdir + name  # 增量镜像目录
            vnc_no = getvncport()
            print vnc_no
            # 查找网卡绑定的对应网桥
            eth_brs = instance.interface_list
            # 把 node 写进数据库
            instance.vncIp = conf.get("EMU", "ServerLocalIP")
            instance.vncPort = vnc_no
            instance.nodeBName = name
            # instance.
            dbqueryobj.saveVGuestInfo(instance)
            # instance_names.append(name)
            sec_fullpath = fullpath + "_bak"
            if IsTemplate == 1:
                if path is None:
                    pass
                else:
                    if os.path.exists(fullpath):
                        logging.info("increment img exists")
                    else:
                        conclusion = -1
                        logging.error("img is not exists")
                res_xml = xenhostgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullimgdir,fullpath, eth_brs,
                                     str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                vir_manager.vir_create(res_xml)
            else:
                increimg = dbqueryobj.getSonNodeDiskFile(instance.id)
                os.popen("qemu-img create -b %s -f qcow2 %s" % (increimg, sec_fullpath))
                if re.search("Windows_10", vm_template_path) is None:
                    res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), sec_fullpath,
                                         eth_brs, str(vnc_no))
                else:
                    res_xml = wintenhostxmlgen(name, int(instance.memory_size) * 1024, sec_fullpath, eth_brs,
                                               str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                os.popen("qemu-img create -b %s -f qcow2 %s" % (increimg, sec_fullpath))
                res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), sec_fullpath, eth_brs,
                                 str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                vir_manager.vir_create(res_xml)


        # 查看实例是否正确创建
        for k, instance in instances.items():
            if vir_manager.searchbyname(instance.nodeBName):
                logging.info("the %s has been build" % (instance.nodeBName))
                errmsg = errmsg + "%s create successful" % instance.nodeBName
                conclusion = 1
                done = done + 1
            else:
                errmsg = errmsg + "%s create failed" % instance.nodeBName
                conclusion = -1

        fulldir = basedir + CaseId + "/"
        config_path = fulldir + "configfile/"  # 用于存放节点目录
        if not os.path.exists(config_path):
            os.makedirs(config_path)

                    # QueryDB.saveVGuestInfo(name)
                # 创建routers
        router_hosts = case_data.router_dict
        router_names = []
        for k, router_host in router_hosts.items():
            # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
            if router_host.emutype == "common":
                vm_template_path = "UB_Router_1004_i386.img"
                print vm_template_path
                path_pre = conf.get("EMU", "TemplateImgFilePre")
                path = path_pre + vm_template_path  # 基础模板路径
                name = "ROUTER_" + str(router_host.id)
                vnc_no = getvncport()
                # 查找网卡绑定的对应网桥
                eth_brs = router_host.interface_list
                # 把 node 写进数据库
                router_host.nodeBName = name
                dbqueryobj.saveVGuestInfo(router_host)
                router_names.append(name)
                fullpath = fullimgdir + name  # 增量镜像路径

                if path is None:
                    logging.error("The base img is not exsits")
                else:
                    if os.path.exists(fullpath):
                        logging.info("increment img exsits,reboot will be ok")
                    else:
                        conclusion = -1
                    # 生成路由xorp配置文件，并且放到相应的目录下
                    fulldir = basedir + CaseId + "/"
                    config_path = fulldir + "configfile/"  # 用于存放节点目录
                    if not os.path.exists(config_path):
                        os.makedirs(config_path)

                    xorp_xml_path = messagedata["define"]["rfile"]
                    xorp_xml_path = conf.get("EMU", "XMLFilePathPre") + xorp_xml_path + "/" + str(
                        router_host.id) + ".xml"
                    print xorp_xml_path
                    xorp_gen_res = xorp_router_format(router_host, xorp_xml_path, config_path)
                    if xorp_gen_res is 0:
                        logging.info("The task of generating of the router's file succeed")
                        # xorp_full_path = config_path + str(router_host.id) + ".boot"
                    else:
                        logging.error("The task of generating of  the router's file failed")
                    # 生成路由信息配置文件，并且放到相应目录下
                    xorp_full_path = config_path + str(router_host.id) + ".boot"
                    router_node_gen = com_router_node_format(router_host, config_path)
                    if router_node_gen is 0:
                        logging.info("The task of generating of the router's node info file succeed")
                        router_node_path = config_path + str(router_host.id) + ".xml"
                    else:
                        logging.error("The task of generating of the router's node info file succeed")

                    # 将生成好的路由文件上传到远程路径下
                    remotexorpdir = conf.get("EMU", "RouterXorpDir")
                    remoteconfigdir = conf.get("EMU", "RouterConfigDir")
                    file_utl = FileOperations()
                    upload_status = file_utl.upload_2_file(fullpath, xorp_full_path, remotexorpdir, router_node_path,
                                                           remoteconfigdir)
                    if upload_status is 0:
                        logging.info("router file upload succeed")
                    else:
                        logging.info("router file upload failed")

                    res_xml = xenhostgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullimgdir,fullpath,
                                         eth_brs, str(vnc_no))
                    print res_xml
                    logging.info("%s" % res_xml)
                    vir_manager.vir_create(res_xml)

            elif router_host.emutype is not "common":
                # vm_template_path = dbqueryobj.getVMTemplate(router_host.templateId)
                vm_template_path = "basis_Cisco_7200.img"
                if vm_template_path is None:
                    logging.info("The path of the template is None")
                print vm_template_path
                path_pre = conf.get("EMU", "TemplateImgFilePre")
                path = path_pre + vm_template_path  # 基础模板路径
                name = "ROUTER_sp" + str(router_host.id)
                vnc_no = getvncport()
                # 查找网卡绑定的对应网桥
                eth_brs = router_host.interface_list
                # 把 node 写进数据库
                router_host.nodeBName = name
                dbqueryobj.saveVGuestInfo(router_host)
                router_names.append(name)
                fullpath = fullimgdir + name  # 增量镜像路径

                if path is None:
                    logging.error("The base img is not exsits")
                else:
                    if os.path.exists(fullpath):
                        logging.info("increment img exists")
                    else:
                        conclusion = -1
                        logging.error("img is not exists")
                    # 生成路由xorp配置文件，并且放到相应的目录下
                    fulldir = basedir + CaseId + "/"
                    config_path = fulldir + "configfile/"  # 用于存放节点目录
                    if not os.path.exists(config_path):
                        os.makedirs(config_path)

                    xorp_xml_path = messagedata["define"]["rfile"]
                    xorp_xml_path = conf.get("EMU", "XMLFilePathPre") + xorp_xml_path + "/" + str(
                        router_host.id) + ".xml"
                    print xorp_xml_path
                    xorp_gen_res = cisco_router_format(router_host, xorp_xml_path, config_path, config_path)
                    if xorp_gen_res is 0:
                        logging.info("The task of generating of the router's file succeed")
                        # xorp_full_path = config_path + str(router_host.id) + ".boot"
                    else:
                        logging.error("The task of generating of  the router's file failed")
                    # 生成路由信息配置文件，并且放到相应目录下
                    cisco_net_file = config_path + "route_7200.net"
                    cisco_exp_file = config_path + str(router_host.id) + ".exp"
                    router_node_gen = com_router_node_format(router_host, config_path)
                    if router_node_gen is 0:
                        logging.info("The task of generating of the router's node info file succeed")
                        router_node_path = config_path + str(router_host.id) + ".xml"
                    else:
                        logging.error("The task of generating of the router's node info file succeed")

                    # 将生成好的路由文件上传到远程路径下
                    remotexorpdir = conf.get("EMU", "SPNETFILE") + "route_7200.net"
                    remoteconfigdir = conf.get("EMU", "SPEXPFILE") + "automation_static.exp"
                    file_utl = FileOperations()
                    upload_status = file_utl.upload_2_file(fullpath, cisco_net_file, remotexorpdir,
                                                           cisco_exp_file, remoteconfigdir)
                    if upload_status is 0:
                        logging.info("router file upload succeed")
                    else:
                        logging.info("router file upload failed")

                    res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullpath,
                                         eth_brs, str(vnc_no))
                    print res_xml
                    logging.info("%s" % res_xml)
                    vir_manager.vir_create(res_xml)

        for key, rou_host in router_hosts.items():
            if vir_manager.searchbyname(rou_host.nodeBName):
                logging.info("the %s has been build" % rou_host.nodeBName)








                # parse the xml
                # xmlres(path, casedatetmp)

                # 1. switch 做循环，创建switch，写数据库
                # 2. host 做循环 ，创建host,写数据库


                # 对于每个host，根据模板id查询模板路径
        # 生成节点名称，即xml中的name， 名字写入数据库
        # 生成镜像文件的名字，基于模板创建镜像文件，生成vnc端口号，测试vnc端口号有没有被占用（命令）
        # generate the libvirt xml
        #   创建虚拟机，
        #   最后查询是否创建成功, 写入数据库

        #   threading.Thread(vir_manager.vir_create())

        # 2. ips 做循环 ，创建ips,写数据库
        # 对于每个ips，根据模板id查询模板路径
        # 生成节点名称，即xml中的name， 名字写入数据库
        # 生成镜像文件的名字，基于模板创建镜像文件，生成vnc端口号，测试vnc端口号有没有被占用（命令）
        # generate the libvirt xml
        # 创建虚拟机，写入数据库
        # 最后查询是否创建成功
        ips_hosts = case_data.ips_dict
        ips_names = []
        for k, ips in ips_hosts.items():
            # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
            vm_template_path = "UB_IPS_1004_i386.img"
            print vm_template_path
            vnc_no = getvncport()
            path_pre = conf.get("EMU", "TemplateImgFilePre")
            path = path_pre + vm_template_path  # 基础模板路径
            name = "IPS_" + str(ips.id)
            vnc_no = getvncport()
            # 查找网卡绑定的对应网桥
            eth_brs = ips.interface_list
            # 把 node 写进数据库
            ips.nodeBName = name
            dbqueryobj.saveVGuestInfo(ips)
            ips_names.append(name)
            fullpath = fullimgdir + name  # 增量镜像路径
            if path is None:
                pass
            else:
                if os.path.exists(fullpath):
                    logging.info("increment img exists")
                else:
                    conclusion = -1
                    logging.error("img is not exists")
                fulldir = basedir + CaseId + "/"
                config_path = fulldir + "configfile/"
                if not os.path.exists(config_path):
                    os.makedirs(config_path)
                ips_get_status = create_ips_xml(ips, config_path)
                IPS_full_path = config_path + str(ips.id) + ".xml"
                remoteconfigdir = conf.get("EMU", "IPSConfigDir")
                file_utl = FileOperations()
                upload_status = file_utl.upload_file(fullpath, IPS_full_path, remoteconfigdir)

                res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullpath, eth_brs,
                                     str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                vir_manager.vir_create(res_xml)

            for k, ips in ips_hosts.items():
                if vir_manager.searchbyname(ips.nodeBName):
                    logging.info("the %s has been build" % (ips.nodeBName))
                else:
                    conclusion = -1






                    # 3. ids 做循环 ，创建ids,写数据库


                    # 对于每个ids，根据模板id查询模板路径
        # 生成节点名称，即xml中的name， 名字写入数据库
        # 生成镜像文件的名字，基于模板创建镜像文件，生成vnc端口号，测试vnc端口号有没有被占用（命令）
        # generate the libvirt xml
        # 创建虚拟机，写入数据库
        # 最后查询是否创建成功
        ids_hosts = case_data.ids_dict
        for k, ids in ids_hosts.items():
            # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
            vm_template_path = "UB_IDS_1004_i386.img"
            print vm_template_path
            vnc_no = getvncport()
            path_pre = conf.get("EMU", "TemplateImgFilePre")
            path = path_pre + vm_template_path  # 基础模板路径
            name = "IDS_" + str(ids.id)
            vnc_no = getvncport()
            # 查找网卡绑定的对应网桥
            eth_brs = ids.interface_list
            # 把 node 写进数据库
            ids.nodeBName = name
            dbqueryobj.saveVGuestInfo(ids)
            instance_names.append(name)
            fullpath = fullimgdir + name  # 增量镜像路径
            if path is None:
                pass
            else:
                if os.path.exists(fullpath):
                    logging.info("increment img exists")
                else:
                    conclusion = -1
                    logging.error("img is not exists")
                fulldir = basedir + CaseId + "/"
                config_path = fulldir + "configfile/"
                if not os.path.exists(config_path):
                    os.makedirs(config_path)
                ids_get_status = create_ids_xml(ids, config_path)
                IDS_full_path = config_path + str(ids.id) + ".xml"
                remoteconfigdir = conf.get("EMU", "IDSConfigDir")
                file_utl = FileOperations()
                upload_status = file_utl.upload_file(fullpath, IDS_full_path, remoteconfigdir)

                res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullpath, eth_brs,
                                     str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                vir_manager.vir_create(res_xml)

                # 4. 防火墙 做循环 ，创建防火墙,写数据库


                # 对于每个防火墙，根据模板id查询模板路径
        # 生成节点名称，即xml中的name， 名字写入数据库
        # 生成镜像文件的名字，基于模板创建镜像文件，生成vnc端口号，测试vnc端口号有没有被占用（命令）
        # generate the libvirt xml
        # 创建虚拟机，写入数据库
        # 最后查询是否创建成功
        # res_xml = hostxmlgen()
        firewall_hosts = case_data.firewall_dict
        for k, firewall in firewall_hosts.items():
            # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
            vm_template_path = "UB_FW_1004_i386.img"
            print vm_template_path
            path_pre = conf.get("EMU", "TemplateImgFilePre")
            path = path_pre + vm_template_path  # 基础模板路径
            name = "FIREWALL_" + str(firewall.id)
            vnc_no = getvncport()
            # 查找网卡绑定的对应网桥
            eth_brs = firewall.interface_list
            # 把 node 写进数据库
            firewall.nodeBName = name
            dbqueryobj.saveVGuestInfo(firewall)
            # instance_names.append(name)
            fullpath = fullimgdir + name  # 增量镜像路径
            if path is None:
                pass
            else:
                if os.path.exists(fullpath):
                    logging.info("increment img exists")
                else:
                    conclusion = -1
                    logging.error("img is not exists")

                firewall_xml_path = messagedata["define"]["rfile"]
                firewall_xml_path = conf.get("EMU", "XMLFilePathPre") + firewall_xml_path + str(firewall.id) + ".xml"

                firewall_get_status = create_firewall_xml(firewall, firewall_xml_path, config_path)
                firewall_full_path = config_path + str(firewall.id) + ".xml"
                remoteconfigdir = conf.get("EMU", "FirewallConfigDir")
                file_utl = FileOperations()
                upload_status = file_utl.upload_file(fullpath, firewall_full_path, remoteconfigdir)

                res_xml = hostxmlgen(name, int(instance.memory_size) * 1024, int(instance.vcpu_no), fullpath, eth_brs,
                                     str(vnc_no))
                print res_xml
                logging.info("%s" % res_xml)
                vir_manager.vir_create(res_xml)

        for k, firewall in firewall_hosts.items():
            if vir_manager.searchbyname(firewall.nodeBName):
                logging.info("the %s has been build" % (firewall.nodeBName))
            else:
                conclusion = -1

        # 发送处理结果消息
        feedback.conclusion = conclusion
        feedback.emessage = errmsg
        feedback.feed_back("EMU2MCUMessageTopic")
