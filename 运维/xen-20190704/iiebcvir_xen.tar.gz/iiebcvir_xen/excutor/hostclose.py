# -*-coding:utf-8-*-
from util.virxml import *
from util.getvnc import *
from util.getbr import *
import os
import sys
import time
from libvirtmodel.libvirtfuc import virtualmanager
import json
from logger.logger import *
import threading
from dao.querydb import QueryDB
from conf.config import ConfParser
from xmlparse.parser import XmlParser
from entity.data import CaseData
from basecls import Base
from entity.feedback import FeedBack
import re
import util.globaldata as gl


class CloseCls(Base):

    def __init__(self):
        pass

    def action(self, message):
        try:
            messagedata = json.loads(message)
        # casedatatmp =CaseData()
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
        feedback = FeedBack()
        feedback.taskid = messagedata["taskid"]
        feedback.name = messagedata["name"]
        feedback.server_ip = messagedata["server_ip"]
        feedback.conclusion = 1
        feedback.emessage = "destroy"
        feedback.feed_back("EMU_KVM2MCUMessageTopic")
        dbqueryobj = QueryDB()
        caseid = messagedata["caseid"]
        caseid = int(caseid)
        vir_hosts = dbqueryobj.selectNodename(caseid)

        vir_manager = virtualmanager()
        for vir_host in vir_hosts:
            try:
                if re.search("linux",vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("windows",vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("ROUTER",vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("IPS", vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("IDS",vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("FIREWALL", vir_host["node_b_name"]) is not None:
                    vir_manager.vir_destroy(vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                elif re.search("ovsbr",vir_host["node_b_name"]) is not None:
                    # vir_manager.vir_destroy(vir_host["node_b_name"])
                    os.popen("ovs-vsctl del-br %s" % vir_host["node_b_name"])
                    logging.info("%s has been destroyed" % vir_host["node_b_name"])
                    print "%s has been destroyed" % vir_host["node_b_name"]
                else:
                    logging.info("Nothing to delete")
            except Exception, e:
                logging.info("%s : %s" % (Exception, e))
        reslist = gl.get_value(str(caseid))
        print reslist
        os.popen("ovs-vsctl list-br| grep hid | xargs ovs-vsctl del-br")
        for res in reslist:
            print res
            try:
                if re.search("hid",res) is not None:
                    os.popen("ovs-vsctl del-br %s" % res)
                    logging.info("%s has been destroyed" % res)
                    print "%s has been destroyed" % res
                elif re.search("nsp", res) is not None:
                    os.popen("ip netns del %s" % res)
                    logging.info("%s has been destroyed" % res)
                    print "%s has been destroyed" % res
                    ovs_port = "os_port" + res[8:13:]
                    # os.popen("")
                else:
                    logging.info("Nothing to delete")
            except Exception, e:
                logging.info("%s : %s" % (Exception, e))
