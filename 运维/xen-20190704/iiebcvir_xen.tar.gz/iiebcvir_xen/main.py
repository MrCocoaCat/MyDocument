# -*-coding:utf-8-*-
import sys
import time
from conf.config import ConfParser
from msgexecutor.msgrev import MQReceiverByTopic
import threading
import util.globaldata as gl


if __name__ == '__main__':
    gl._init()
    conf = ConfParser()
    MQIP = conf.get("MQ","MQServerip")
    RevTopic = conf.get("MQ","MCU2EMUMessageTopicPre")

    RevHeartTopic = conf.get("MQ", "MCU2EMUAliveTopic")
    LocalIP = conf.get("EMU","ServerLocalIP")
    RTopic = RevTopic + LocalIP
    msgrev = MQReceiverByTopic(MQIP, 61613)
    thread1 = threading.Thread(target=msgrev.subscribe_topic, args=(RTopic,))
    thread1.setDaemon(True)
    thread1.start()
    thread2 = threading.Thread(target=msgrev.subscribe_topic, args=(RevHeartTopic,))
    thread2.setDaemon(True)
    thread2.start()
    try:
        while True:
            pass
    except (KeyboardInterrupt, SystemExit):
        print "test over"
