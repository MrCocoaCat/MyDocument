
import ctypes

class switch(object):
    def __init__(self, value):
        self.value = value
        self.fall = False

    def __iter__(self):
        """Return the match method once, then stop"""
        yield self.match
        raise StopIteration

    def match(self, *args):
        """Indicate whether or not to enter a case suite"""
        if self.fall or not args:
            return True
        elif self.value in args: # changed for v1.5, see below
            self.fall = True
            return True
        else:
            return False


def int_overflow(val):
    maxint = 2147483647
    if not -maxint-1 <= val <= maxint:
        val = (val + (maxint + 1)) % (2 * (maxint + 1)) - maxint - 1
    return val


def unsigned_right_shitf(n,i):

    if n<0:
        n = ctypes.c_uint32(n).value

    if i<0:
        return -int_overflow(n << abs(i))

    return int_overflow(n >> i)



def murmurhash64(data,length,seed):

    UNSIGNED_MASK = 0xff;


    UINT_MASK = 0xFFFFFFFFl;


    LONG_MASK = 0xFFFFFFFFFFFFFFFFL;

    m = 0xc6a4a7935bd1e995L
    r =47
    h = (seed & UINT_MASK) ^ (length * m)

    length8 = length>>3

    for i in range(length8):
        print i
        i8 = i <<3
        k = (long(ord(data[i8])) & 0xff) +((long(ord(data[i8+1]))&0xff)<<8)    \
                    +((long(ord(data[i8+2]))&0xff)<<16) +((long(ord(data[i8+3]))&0xff)<<24)  \
                    +((long(ord(data[i8+4]))&0xff)<<32) +((long(ord(data[i8+5]))&0xff)<<40)   \
                    +((long(ord(data[i8+6]))&0xff)<<48) +((long(ord(data[i8+7]))&0xff)<<56)
        print type(k)
        k = k * m
        k = k ^ unsigned_right_shitf(k,r)
        k = k * m
        h = h ^ k
        h = h * m
        print h
    for case in switch(length & 7):
        if case(7):
            h = h ^ (long((ord(data[(length & ~7) + 6])) & 0xff) << 48)
        if case(6):
            h = h ^ (long((ord(data[(length & ~7) + 5])) & 0xff) << 40)
        if case(5):
            h = h ^ (long((ord(data[(length & ~7) + 4])) & 0xff) << 32)
        if case(4):
            h = h ^ (long((ord(data[(length & ~7) + 3])) & 0xff) << 24)
        if case(3):
            h = h ^ (long((data[(length & ~7) + 2] & 0xff)) << 16)
        if case(2):
            h = h ^ (long((data[(length & ~7) + 1] & 0xff)) << 8 )
        if case(1):
            h = h ^ (long((ord(data[length & ~7])) & 0xff))
            h = h * m

        h = h ^ unsigned_right_shitf(h, r)
        h *= m
        h = h ^ unsigned_right_shitf(h, r)

        return h
print murmurhash64("sdfsdfsdf",9,1234)


''' public static long hash64(final byte[] data, int length, long seed) {
        final long m = 0xc6a4a7935bd1e995L;
        final int r = 47;

        long h = (seed & UINT_MASK) ^ (length * m);

        int length8 = length >> 3;

        for (int i = 0; i < length8; i++) {
            final int i8 = i << 3;

            long k =  ((long)data[i8]&0xff) +(((long)data[i8+1]&0xff)<<8)
                    +(((long)data[i8+2]&0xff)<<16) +(((long)data[i8+3]&0xff)<<24)
                    +(((long)data[i8+4]&0xff)<<32) +(((long)data[i8+5]&0xff)<<40)
                    +(((long)data[i8+6]&0xff)<<48) +(((long)data[i8+7]&0xff)<<56);

            k *= m;
            k ^= k >>> r;
            k *= m;

            h ^= k;
            h *= m;
        }

        switch (length & 7) {
            case 7:
                h ^= (long) (data[(length & ~7) + 6] & 0xff) << 48;

            case 6:
                h ^= (long) (data[(length & ~7) + 5] & 0xff) << 40;

            case 5:
                h ^= (long) (data[(length & ~7) + 4] & 0xff) << 32;

            case 4:
                h ^= (long) (data[(length & ~7) + 3] & 0xff) << 24;

            case 3:
                h ^= (long) (data[(length & ~7) + 2] & 0xff) << 16;

            case 2:
                h ^= (long) (data[(length & ~7) + 1] & 0xff) << 8;

            case 1:
                h ^= (long) (data[length & ~7] & 0xff);
                h *= m;
        }

        h ^= h >>> r;
        h *= m;
        h ^= h >>> r;

        return h;
    }'''

print "test"