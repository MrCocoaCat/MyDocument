import  util.globaldata as gl
from msgexecutor.bb import *
from task.aa import *

gl._init()
mod1()
mod2()
