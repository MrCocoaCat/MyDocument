# -*-coding:utf-8-*-
import sys
sys.path.append("../")
from xmlparse.parser import XmlParser
from entity.data import CaseData


if __name__ == '__main__':
    load = "C:\Users\zjl\Desktop\8624_treated.xml"
    casedata = CaseData()
    parsexml = XmlParser()
    data = parsexml.parse_xml(load, casedata)
    # subnet = parsexml.parse_xml_subnet(load, casedata)
    # print subnet
    # print data
    # print casedata.switch_dict
    # print casedata.hid_switch_dict
    # print casedata.virhost_dict
    # print casedata.router_dict
    for k, v in casedata.router_dict.items():
        print v.interface_list[0].link_type
    # print casedata.firewall_dict
    # print casedata.ips_dict
    # print casedata.ids_dict
    # for k, v in casedata.subnet_dict.items():
    #     print v.switch_dict
        # for k, v in v.switch_dict:
        #     print v.id