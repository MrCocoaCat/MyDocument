# -*-coding:utf-8-*-
import sys
sys.path.append("../")
from msgexecutor.msgrev import MQReceiverByTopic
from msgexecutor.mqhandle import MyListener
import threading

if __name__ == '__main__':
    msgrev = MQReceiverByTopic("192.168.122.222", 61613)
    thread1 = threading.Thread(target=msgrev.subscribe_topic, args=("MCU2EMUMessageTopicPre_192.168.122.96",))
    thread1.setDaemon(True)
    thread1.start()
    thread2 = threading.Thread(target=msgrev.subscribe_topic, args=("MCU2BACKEND_ALIVE",))
    thread2.setDaemon(True)
    thread2.start()
    try:
        while True:
            pass
    except (KeyboardInterrupt, SystemExit):
        print "test over"
