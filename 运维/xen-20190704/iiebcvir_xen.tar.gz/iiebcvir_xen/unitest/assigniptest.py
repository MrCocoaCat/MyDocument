# -*-coding:utf-8-*-

from entity.data import CaseData
from xmlparse.parser import XmlParser
from assignip.assignip import AssignIp
from logger.logger import *


if __name__ == '__main__':
    load = "C:\Users\zjl\Desktop\8624_treated.xml"
    casedata = CaseData()
    parseres = XmlParser()
    assignip = AssignIp()
    res = parseres.parse_xml(load, casedata)
    if res == 0:
        id = casedata.keys()[0]
        assignip.openmasq(casedata, id)
    else:
        logging.error('error:Parsing XML failed')






