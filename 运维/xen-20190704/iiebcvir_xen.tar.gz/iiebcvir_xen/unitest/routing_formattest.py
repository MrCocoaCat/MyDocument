# -*-coding:utf-8-*-

from util.routing_format import *
from entity.data import CaseData
from xmlparse.parser import XmlParser

if __name__ == '__main__':
    from logger.logger import *
    #测试xorp_router_format
    # path1 = '/home/sample.xml'
    # path2 = '/home/1611296.xml'
    # path3 = '/home'
    # xmlparse = XmlParser()
    # casedata = CaseData()
    # a = xmlparse.parse_xml(path1, casedata)
    # router = casedata.router_dict
    # try:
    #     for k, v in router.items():
    #         a = xorp_router_format(v, path2, path3)
    #         print a
    # except Exception, e:
    #     logging.error("%s: %s" % (Exception, e))

    #测试com_router_node_format
    # path = "C:\Users\zjl\Desktop\8624_treated.xml"
    # load = 'C:\Users\zjl\Desktop'
    # xmlparse = XmlParser()
    # casedata = CaseData()
    # a = xmlparse.parse_xml(path, casedata)
    # router = casedata.router_dict
    # try:
    #     for k, v in router.items():
    #         b = com_router_node_format(v, load)
    #         print b
    # except Exception, e:
    #     logging.error("%s: %s" % (Exception, e))

    #测试create_firewall_xml
    # path = "C:\Users\zjl\Desktop\8624_treated.xml"
    # load = 'C:\Users\zjl\Desktop'
    # load1 = 'C:\Users\zjl\Desktop\96.xml'
    # xmlparse = XmlParser()
    # casedata = CaseData()
    # a = xmlparse.parse_xml(path, casedata)
    # firewall = casedata.firewall_dict
    # try:
    #     for k, v in firewall.items():
    #         b = create_firewall_xml(v, load1, load)
    #         print b
    # except Exception, e:
    #     logging.error("%s: %s" % (Exception, e))

    # 测试create_ips_xml
    # path = "C:\Users\zjl\Desktop\8624_treated.xml"
    # load = 'C:\Users\zjl\Desktop'
    # xmlparse = XmlParser()
    # casedata = CaseData()
    # a = xmlparse.parse_xml(path, casedata)
    # ips = casedata.ips_dict
    # try:
    #     for k, v in ips.items():
    #         b = create_ips_xml(v, load)
    #         print b
    # except Exception, e:
    #     logging.error("%s: %s" % (Exception, e))

    # path = "C:\Users\zjl\Desktop\8624_treated.xml"
    # load = 'C:\Users\zjl\Desktop'
    # xmlparse = XmlParser()
    # casedata = CaseData()
    # a = xmlparse.parse_xml(path, casedata)
    # ids = casedata.ids_dict
    # try:
    #     for k, v in ids.items():
    #         b = create_ids_xml(v, load)
    #         print b
    # except Exception, e:
    #     logging.error("%s: %s" % (Exception, e))

    # ip = "192.121.101.166"
    # mask = "255.255.0.0"
    # print exchange_mask(mask)

    path = "C:\Users\zjl\Desktop\8624_treated.xml"
    load = 'C:\Users\zjl\Desktop'
    load1 = 'C:\Users\zjl\Desktop\96.xml'
    xmlparse = XmlParser()
    casedata = CaseData()
    a = xmlparse.parse_xml(path, casedata)
    router = casedata.router_dict
    try:
        for k, v in router.items():
            b = cisio_router_format(v, load1, load, load)
            print b
    except Exception, e:
        logging.error("%s: %s" % (Exception, e))
