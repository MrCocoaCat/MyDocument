# -*-coding:utf-8-*-
import sys
sys.path.append("../")
from conf.config import ConfParser



if __name__ == '__main__':
    confpath = "../confpath/config.ini"
    conftest = ConfParser(confpath)
    avir = conftest.items("AVIR")
    hypervisor = conftest.items("HYPERVISOR")
    mq = conftest.items("MQ")
    for i in avir:
        print i
    for j in hypervisor:
        print j
    for k in mq:
        print k

