# -*-coding:utf-8-*-
import sys
sys.path.append("../")
from xmlparse.nodeinfo import *
if __name__ == '__main__':
    load = "/home/sample.xml"
    res = get_guest(load)
    print res[0]
