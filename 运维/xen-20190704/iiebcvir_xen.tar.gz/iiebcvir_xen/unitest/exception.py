import logging
def test():
    try:
        test.deploy(message)
    except Exception,e:
        logging.error("%s : %s" % (Exception, e))
test()
