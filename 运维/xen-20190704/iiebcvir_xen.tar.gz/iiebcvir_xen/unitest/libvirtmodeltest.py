# -*-coding:utf-8-*-
import sys
sys.path.append("../")
from libvirtmodel.libvirtfuc import virtualmanager
from util.virxml import *

if __name__ == '__main__':
    xmlsample = hostxmlgen()
    test = virtualmanager()

    test.vir_create(xmlsample)

    test.searchbyname("route2")

    test.searchbyid(2)
    print "print 1 and pause the instance"

    a = raw_input()
    int(a)
    if a is 1:
        test.vir_pause("route2")
    print "print 2 and resume the instance"

    a = raw_input()
    int(a)

    if a is 2:
        test.vir_resume("route2")
