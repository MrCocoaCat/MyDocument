# -*-coding:utf-8-*-
from util.fileupload import FileOperations

if __name__ == '__main__':
    uploadfile = FileOperations()
    disk = '/home/zjl/zjltest.img'
    file = '/root/dbtest/dbtest.py'
    remotefile = '/etc/zjltest.py'
    a = uploadfile.upload_file(disk, file, remotefile)
    print a
