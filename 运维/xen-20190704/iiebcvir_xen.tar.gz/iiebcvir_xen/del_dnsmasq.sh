ps aux | pidof dnsmasq | xargs kill -9
