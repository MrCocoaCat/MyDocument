# -*-coding:utf-8-*-
import ConfigParser
from logger.logger import *
import os
class ConfParser:
    def __init__(self, conf_path="/etc/confpath/config.ini"):
        self.fpath = conf_path  # configfile path
        self.cf = ConfigParser.ConfigParser()  # ConfigParser object instance
        self.cf.read(self.fpath)  # read

    def isexists(self):
        return os.path.exists(self.fpath)

    def __del__(self):
        if self.isexists():
            with open(self.fpath, 'w') as fh:
                self.cf.write(fh)
        else:
            logging.error("%s is not exsist" % self.fpath)

    # add the section
    def add_section(self, s):
        sections = self.cf.sections()
        if s in sections:
            return
        else:
            self.cf.add_section(s)

    def remove_section(self, s):
        return self.cf.remove_section(s)

    def get(self, s, o):
        return self.cf.get(s, o)

    def set(self, s, o, v):
        if self.cf.has_section(s):
            self.cf.set(s, o, v)

    def remove_option(self, s, o):
        if self.cf.has_section(s):
            return self.cf.remove_option(s, o)
        return False


    def items(self, s):
        return self.cf.items(s)


    def sections(self):
        return self.cf.sections()

    def options(self, s):
        return self.cf.options(s)
