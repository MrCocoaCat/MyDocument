# -*-coding:utf-8-*-
import json
try:
    import xml.etree.cElementTree as ET  #导入cElementTree解析xml文件
except ImportError:  #如果没有的话
    import xml.etree.ElementTree as ET  #导入ElementTree解析xml文件，cElementTree比ElementTree速度要快，占内存更小
import sys

from logger.logger import *
from entity.data import *
from conf.config import ConfParser
from util.network import *


conf = ConfParser()
node_type = NodeType()


class XmlParser(object):
    def __init__(self):
        pass

    def parse_xml(self, path, case_data):
        try:
            tree = ET.parse(path)  # 找到xml文件的位置，并打开
            root = tree.getroot()  # 获取该xml文件的根节点
            # 判断__parse_switch的返回值是否为0，如果是0代表返回正确，如果不是代表程序有错，错误会打印在日志里面
            if 0 == self.__parse_switch(root.findall('emu_switch'), case_data):
                # __parse_switch没有问题，继续向下判断__parse_guest，以下原理一样
                if 0 == self.__parse_guest(root.findall('emu_host'), case_data):
                    if 0 == self.__parse_guest(root.findall('emu_server'), case_data):
                        return 0
                    else:
                        logging.error("Parse Server ERROR!\t\t[ERROR]")
                        return -1
                else:
                    logging.error("Parse Guest ERROR!\t\t[ERROR]")
                    return -1
            else:
                logging.error("Parse Switch ERROR!\t\t[ERROR]")
                return -1
        except Exception, e:
            logging.error("%s:%s" % (Exception,e))
            return -1

    # 解析emu_switch的xml，把数据都写在casedata.switch_dict里面，如果程序无误返回0，有错返回-1
    def __parse_switch(self, switch_nodes, case_data):
        # switch_nodes是一个列表，需要遍历把里面的数据拿出来
        for switch_node in switch_nodes:
            # 实例化Switch对象
            switch = Switch()
            # 遍历从switch_node找出来的interface
            for interface_node in switch_node.findall('interface'):
                # 实例化EmuInterface对象
                interface = EmuInterface()
                # 向EmuInterface的对象中填数据
                interface.id = interface_node.get('id')
                interface.boundary = interface_node.get('boundary')
                # 如果interface.boundary的值为0，即没有边界，往下走
                if int(interface.boundary) == 0:
                    link_node = interface_node.find('link')
                    # 判断link连接是否为emu_switch，如果是的话表示他们在一个子网，把他们的网卡信息放在一个列表中
                    if 'emu_switch' == link_node.get('type'):
                        switch_id = link_node.text
                        switch.linkto_emu_switch_list.append(switch_id)
                    # 不是的话不处理
                    else:
                        pass
                # 如果interface.boundary为1，也就是有边界，记录下peth字段的信息，并把这个网卡放到boundary_interface_list里
                else:
                    interface.p_eth = interface_node.get('peth')
                    switch.boundary_interface_list.append(interface)
                switch.interface_list.append(interface)
            switch.hypervisor = switch_node.find('hypervisor').get('name')
            switch.id = long(switch_node.get('id'))
            case_data.switch_dict[switch.id] = switch
        return 0

    # 处理隐藏switch的名字
    def __generate_hid_switch_name(self, src_id, src_interface_id, dst_id, dst_interface_id):
        if long(src_id) > long(dst_id):
            hid_switch_id = str(dst_id) + str(dst_interface_id) + str(src_id) + str(src_interface_id)
        else:
            hid_switch_id = str(src_id) + str(src_interface_id) + str(dst_id) + str(dst_interface_id)
        return hid_switch_id

    # 解析emu_host的xml，把数据都写在casedata.virhost_dict里面，如果程序无误返回0，有错返回-1
    def __parse_guest(self, guest_nodes, case_data):
        for host_node in guest_nodes:
            guest = Guest()
            for interface_node in host_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = get_mac()
                emuInterface.ip = get_ip()
                emuInterface.mask = "255.255.255.0"
                emuInterface.gateway = "192.168.125.254"
                link_node = interface_node.find('link')
                if 'emu_switch' == link_node.get('type'):
                    link2side = link_node.text
                    tempSwitch = case_data.switch_dict[long(link2side)]
                    emuInterface.Switch = tempSwitch
                else:
                    logging.error("error:the host cannot connect to all devices other than emu_switch")
                guest.interface_list.insert(emuInterface.id, emuInterface)
            apps_node = host_node.find('apps')
            if apps_node is None:
                guest.apps = []
            else:
                for app in apps_node:
                    app_id = app.get('id')
                    guest.apps.append(app_id)
            guest.hypervisor = host_node.find('hypervisor').get('name')
            guest.osType = host_node.find('os').find('type').text
            guest.templateId = int(host_node.find('template').get('id'))
            guest.vcpu_no = int(host_node.find('vcpu').text)
            guest.memory_size = int(host_node.find('memory').text)
            guest.id = long(host_node.get('id'))
            case_data.virhost_dict[guest.id] = guest
        return 0


