# -*-coding:utf-8-*-
import json
try:
    import xml.etree.cElementTree as ET  #导入cElementTree解析xml文件
except ImportError:  #如果没有的话
    import xml.etree.ElementTree as ET  #导入ElementTree解析xml文件，cElementTree比ElementTree速度要快，占内存更小
import sys

from logger.logger import *
from entity.data import *
from conf.config import ConfParser
from entity.subnet import Subnet


conf = ConfParser()
node_type = NodeType()


class XmlParser(object):
    def __init__(self):
        pass

    def parse_xml_subnet(self, path, case_data):
        tree = ET.parse(path)  # 找到xml文件的位置，并打开
        root = tree.getroot()  # 获取该xml文件的根节点
        if 0 == self.__parse_subnet(root.findall('subnet'), case_data):
            return 0
        else:
            logging.error("error:parse subnet error!\t\t[error]")
            return -1
        #todo

    def __parse_subnet(self, subnet_nodes, case_data):
        try:
            for subnet_node in subnet_nodes:
                subnet = Subnet()
                flag = False    #是否是仿真子网
                link_nodes = subnet_node.findall('link')
                for link_node in link_nodes:
                    if link_node.get('type')[0:3] == 'emu':
                        if flag is False:
                            flag = True
                        link_type = link_node.get('type')
                        link_node_id = long(link_node.text)
                        link_node_interface_id = int(link_node.get('interface'))
                        link_node_interface_using_type = int(link_node.get('using_type'))

                        if 'emu_router' == link_type:
                            if case_data.router_dict.has_key(link_node_id) == False:
                                continue
                            router = case_data.router_dict[link_node_id]
                            subnet.interface_list.append((router.interface_list[link_node_interface_id],
                                                         int(conf.get('EMU', 'NeedDHCPAssignMagicNumber')) & node_type.COM_ROUTER))
                            switch = router.interface_list[link_node_interface_id].Switch
                            if subnet.is_switch_exist(switch.ovsbr_name
                                                      ) is False:
                                subnet.switch_dict[switch.ovsbr_name] = switch
                        elif 'emu_ips' == link_type:
                            if link_node_interface_using_type == 1: #非管理口不需要处理，由子网中的其他节点引入switch，非管理口不需要分配IP
                                if case_data.ips_dict.has_key(link_node_id) == False:
                                    continue
                                ips = case_data.ips_dict[link_node_id]
                                subnet.interface_list.append((ips.interface_list[link_node_interface_id],
                                                             int(conf.get('EMU', 'NeedDHCPAssignMagicNumber')) & node_type.COM_IPS))
                                switch = ips.interface_list[link_node_interface_id].Switch
                                if subnet.is_switch_exist(switch.ovsbr_name) is False:
                                    subnet.switch_dict[switch.ovsbr_name] = switch
                        elif 'emu_firewall' == link_type:
                            if case_data.firewall_dict.has_key(link_node_id) == False:
                                continue
                            fw = case_data.firewall_dict[link_node_id]
                            subnet.interface_list.append((fw.interface_list[link_node_interface_id],
                                                         int(conf.get('EMU', 'NeedDHCPAssignMagicNumber')) & node_type.COM_FW))
                            switch = fw.interface_list[link_node_interface_id].Switch
                            if subnet.is_switch_exist(switch.ovsbr_name) is False:
                                subnet.switch_dict[switch.ovsbr_name] = switch

                        elif 'emu_ids' == link_type: #此处暂时不用区分网卡类别
                            if case_data.ids_dict.has_key(link_node_id) == False:
                                continue
                            ids = case_data.ids_dict[link_node_id]
                            subnet.interface_list.append((ids.interface_list[link_node_interface_id],
                                                         int(conf.get('EMU', 'NeedDHCPAssignMagicNumber')) & node_type.COM_IDS))
                            switch = ids.interface_list[link_node_interface_id].Switch
                            if subnet.is_switch_exist(switch.ovsbr_name) is False:
                                subnet.switch_dict[switch.ovsbr_name] = switch

                        elif 'emu_host' == link_type or 'emu_server' == link_type:
                            if case_data.virhost_dict.has_key(link_node_id) == False:
                                continue
                            host = case_data.virhost_dict[link_node_id]
                            subnet.interface_list.append((host.interface_list[link_node_interface_id],
                                                         int(conf.get('EMU', 'NeedDHCPAssignMagicNumber')) & node_type.VHOST))
                            switch = host.interface_list[link_node_interface_id].Switch
                            if subnet.is_switch_exist(switch.ovsbr_name) is False:
                                subnet.switch_dict[switch.ovsbr_name] = switch
                if flag :
                    #解析id并给subnet.id赋值
                    subnet.id = subnet_node.get('id')
                    # 解析ipbase netmask gateway并给subnet赋值
                    subnet.ipbase = subnet_node.find('ip').get('ipbase')
                    subnet.ipmask = subnet_node.find('ip').get('ipmask')
                    subnet.gateway = subnet_node.find('ip').get('gateway')
                    case_data.subnet_dict[subnet.id] = subnet
                    print case_data.subnet_dict
            return 0
        except Exception, e:
            logging.error("%s:%s" % (Exception, e))
            return -1



    def parse_xml(self, path, case_data):
        try:
            tree = ET.parse(path)  # 找到xml文件的位置，并打开
            root = tree.getroot()  # 获取该xml文件的根节点
            # 判断__parse_switch的返回值是否为0，如果是0代表返回正确，如果不是代表程序有错，错误会打印在日志里面
            if 0 == self.__parse_switch(root.findall('emu_switch'), case_data):
                # __parse_switch没有问题，继续向下判断__parse_guest，以下原理一样
                if 0 == self.__parse_guest(root.findall('emu_host'), case_data):
                    if 0 == self.__parse_guest(root.findall('emu_server'), case_data):
                        if 0 == self.__parse_router(root.findall('emu_router'), case_data):
                            if 0 == self.__parse_firewall(root.findall('emu_firewall'), case_data):
                                if 0 == self.__parse_ips(root.findall('emu_ips'), case_data):
                                    if 0 == self.__parse_ids(root.findall('emu_ids'), case_data):
                                        return 0
                                    else:
                                        logging.error("Parse Ids ERROR!\t\t[ERROR]")
                                        return -1
                                else:
                                    logging.error("Parse Ips ERROR!\t\t[ERROR]")
                                    return -1
                            else:
                                logging.error("Parse Firewall ERROR!\t\t[ERROR]")
                                return -1
                        else:
                            logging.error("Parse Router ERROR!\t\t[ERROR]")
                            return -1
                    else:
                        logging.error("Parse Server ERROR!\t\t[ERROR]")
                        return -1
                else:
                    logging.error("Parse Guest ERROR!\t\t[ERROR]")
                    return -1
            else:
                logging.error("Parse Switch ERROR!\t\t[ERROR]")
                return -1
        except Exception, e:
            logging.error("%s:%s" % (Exception,e))
            return -1

    # 解析emu_switch的xml，把数据都写在casedata.switch_dict里面，如果程序无误返回0，有错返回-1
    def __parse_switch(self, switch_nodes, case_data):
        # switch_nodes是一个列表，需要遍历把里面的数据拿出来
        for switch_node in switch_nodes:
            # 实例化Switch对象
            switch = Switch()
            # 遍历从switch_node找出来的interface
            for interface_node in switch_node.findall('interface'):
                # 实例化EmuInterface对象
                interface = EmuInterface()
                # 向EmuInterface的对象中填数据
                interface.id = interface_node.get('id')
                interface.boundary = interface_node.get('boundary')
                interface.link_type = interface_node.find('link').get('type')
                # 如果interface.boundary的值为0，即没有边界，往下走
                if int(interface.boundary) == 0:
                    link_node = interface_node.find('link')
                    # 判断link连接是否为emu_switch，如果是的话表示他们在一个子网，把他们的网卡信息放在一个列表中
                    if 'emu_switch' == link_node.get('type'):
                        switch_id = link_node.text
                        switch.linkto_emu_switch_list.append(switch_id)
                    # 不是的话不处理
                    else:
                        pass
                # 如果interface.boundary为1，也就是有边界，记录下peth字段的信息，并把这个网卡放到boundary_interface_list里
                else:
                    interface.p_eth = interface_node.get('peth')
                    switch.boundary_interface_list.append(interface)
                switch.interface_list.append(interface)
            switch.hypervisor = switch_node.find('hypervisor').get('name')
            switch.id = long(switch_node.get('id'))
            case_data.switch_dict[switch.id] = switch
        return 0

    # 处理隐藏switch的名字
    def __generate_hid_switch_name(self, src_id, src_interface_id, dst_id, dst_interface_id):
        if long(src_id) > long(dst_id):
            hid_switch_id = str(dst_id) + str(dst_interface_id) + str(src_id) + str(src_interface_id)
        else:
            hid_switch_id = str(src_id) + str(src_interface_id) + str(dst_id) + str(dst_interface_id)
        return hid_switch_id

    # 解析emu_host的xml，把数据都写在casedata.virhost_dict里面，如果程序无误返回0，有错返回-1
    def __parse_guest(self, guest_nodes, case_data):
        for host_node in guest_nodes:
            guest = Guest()
            for interface_node in host_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = interface_node.get('mac')
                emuInterface.ip = interface_node.find('ip').get('address')
                emuInterface.mask = interface_node.find('ip').get('netmask')
                emuInterface.gateway = interface_node.find('ip').get('gateway')
                emuInterface.link_type = interface_node.find('link').get('type')
                link_node = interface_node.find('link')
                if 'emu_switch' == link_node.get('type'):
                    link2side = link_node.text
                    tempSwitch = case_data.switch_dict[long(link2side)]
                    emuInterface.Switch = tempSwitch
                else:
                    logging.error("error:the host cannot connect to all devices other than emu_switch")
                guest.interface_list.insert(emuInterface.id, emuInterface)
            guest.hypervisor = host_node.find('hypervisor').get('name')
            guest.osType = host_node.find('os').find('type').text
            guest.templateId = int(host_node.find('template').get('id'))
            guest.vcpu_no = int(float(host_node.find('vcpu').text))
            guest.memory_size = int(host_node.find('memory').text)
            guest.id = long(host_node.get('id'))
            case_data.virhost_dict[guest.id] = guest
        return 0

    # 解析emu_router的xml，把数据都写在casedata.router_dict里面，如果程序无误返回0，有错返回-1
    def __parse_router(self, router_nodes, case_data):
        for router_node in router_nodes:
            router = Router()
            router.id = long(router_node.get('id'))
            router.emutype = router_node.find('hypervisor').get('type')
            router.hypervisor = router_node.find('hypervisor').get('name')
            router.templateId = int(router_node.find('template').get('id'))
            # 遍历interface节点的信息
            for interface_node in router_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = interface_node.get('mac')
                emuInterface.ip = interface_node.find('ip').get('address')
                emuInterface.mask = interface_node.find('ip').get('netmask')
                emuInterface.gateway = interface_node.find('ip').get('gateway')
                emuInterface.link_type = interface_node.find('link').get('type')
                link_node = interface_node.find('link')
                if int(emuInterface.boundary) == 1:
                    emuInterface.p_eth = interface_node.get('peth')
                    dst_id = link_node.text
                    dst_interface_id = link_node.get('dst_if')
                    hid_switch_b_name = self.__generate_hid_switch_name(router.id, emuInterface.id, dst_id, dst_interface_id)
                    if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                        hid_switch = Switch()
                        hid_switch.ovsbr_name = hid_switch_b_name
                        hid_switch.boundary_interface_list.append(emuInterface)
                        case_data.hid_switch_dict[hid_switch_b_name] = hid_switch
                        emuInterface.Switch = hid_switch
                    else:
                        hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                        emuInterface.Switch = hid_switch
                else:
                    if 'emu_switch' == link_node.get('type'):
                        link2side = link_node.text
                        temp_switch = case_data.switch_dict[long(link2side)]
                        emuInterface.Switch = temp_switch
                    elif 'emu_router' == link_node.get('type') or 'emu_ips' == link_node.get('type') or 'emu_firewall' == link_node.get('type'):
                        dst_id = link_node.text
                        dst_interface_id = link_node.get('dst_if')
                        hid_switch_b_name = self.__generate_hid_switch_name(router.id, emuInterface.id, dst_id, dst_interface_id)
                        if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                            hid_switch = Switch()
                            hid_switch.ovsbr_name = hid_switch_b_name
                            case_data.hid_switch_dict[hid_switch_b_name] = hid_switch
                            emuInterface.Switch = hid_switch
                        else:
                            hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                            emuInterface.Switch = hid_switch
                    else:
                        logging.error("error:the router cannot connect to emu_ids, emu_host and emu_server")
                router.interface_list.insert(emuInterface.id, emuInterface)
            case_data.router_dict[router.id] = router
        return 0

    # 解析emu_firewall的xml，把数据都写在casedata.firewall_dict里面，如果程序无误返回0，有错返回-1
    def __parse_firewall(self, firewall_nodes, case_data):
        for firewall_node in firewall_nodes:
            firewall = Firewall()
            firewall.id = long(firewall_node.get('id'))
            firewall.hypervisor = firewall_node.find('hypervisor').get('name')
            for interface_node in firewall_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = interface_node.get('mac')
                emuInterface.ip = interface_node.find('ip').get('address')
                emuInterface.mask = interface_node.find('ip').get('netmask')
                emuInterface.gateway = interface_node.find('ip').get('gateway')
                emuInterface.link_type = interface_node.find('link').get('type')
                emuInterface.usage_type = interface_node.find('using_type').text
                link_node = interface_node.find('link')
                if int(emuInterface.boundary) == 1:
                    emuInterface.p_eth = interface_node.get('peth')
                    dst_id = link_node.text
                    dst_interface_id = link_node.get('dst_if')
                    hid_switch_b_name = self.__generate_hid_switch_name(firewall.id, emuInterface.id, dst_id,dst_interface_id)
                    if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                        hid_switch = Switch()
                        hid_switch.ovsbr_name = hid_switch_b_name
                        hid_switch.boundary_interface_list.append(emuInterface)
                        case_data.hid_switch_dict[hid_switch_b_name] = hid_switch
                        emuInterface.Switch = hid_switch
                    else:
                        hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                        emuInterface.Switch = hid_switch
                else:
                    if 'emu_switch' == link_node.get('type'):
                        link2side = link_node.text
                        temp_switch = case_data.switch_dict[long(link2side)]
                        emuInterface.Switch = temp_switch
                    elif 'emu_router' == link_node.get('type') or 'emu_ips' == link_node.get('type') or 'emu_firewall' == link_node.get('type'):
                        dst_id = link_node.text
                        dst_interface_id = link_node.get('dst_if')
                        hid_switch_b_name = self.__generate_hid_switch_name(firewall.id, emuInterface.id, dst_id, dst_interface_id)
                        if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                            hid_switch = Switch()
                            hid_switch.ovsbr_name = hid_switch_b_name
                            case_data.hid_switch_dict[hid_switch_b_name] = hid_switch
                            emuInterface.Switch = hid_switch
                        else:
                            hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                            emuInterface.Switch = hid_switch
                    else:
                        logging.error("error:the firewall cannot connect to emu_ids, emu_host and emu_server")
                firewall.interface_list.insert(emuInterface.id, emuInterface)
            for rule_node in firewall_node.find('rules').findall('rule'):
                firewall.rules.append(rule_node.attrib)
            for portfilter_node in firewall_node.find('portfilter').findall('rule'):
                firewall.portFilter.append(portfilter_node.attrib)
            case_data.firewall_dict[firewall.id] = firewall
        return 0

    # 解析emu_ips的xml，把数据都写在casedata.ips_dict里面，如果程序无误返回0，有错返回-1
    def __parse_ips(self, ips_nodes, case_data):
        for ips_node in ips_nodes:
            ips = Ips()
            ips.id = long(ips_node.get('id'))
            ips.hypervisor = ips_node.find('hypervisor').get('name')
            for interface_node in ips_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = interface_node.get('mac')
                emuInterface.ip = interface_node.find('ip').get('address')
                emuInterface.mask = interface_node.find('ip').get('netmask')
                emuInterface.gateway = interface_node.find('ip').get('gateway')
                emuInterface.link_type = interface_node.find('link').get('type')
                emuInterface.usage_type = interface_node.find('using_type').text
                link_node = interface_node.find('link')
                if int(emuInterface.boundary) == 1:
                    emuInterface.p_eth = interface_node.get('peth')
                    dst_id = link_node.text
                    dst_interface_id = link_node.get('dst_if')
                    hid_switch_b_name = self.__generate_hid_switch_name(ips.id, emuInterface.id, dst_id, dst_interface_id)
                    if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                        hid_switch = Switch()
                        hid_switch.ovsbr_name = hid_switch_b_name
                        hid_switch.boundary_interface_list.append(emuInterface)
                        case_data.hid_switch_dict[hid_switch_b_name] = hid_switch
                        emuInterface.Switch = hid_switch
                    else:
                        hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                        emuInterface.Switch = hid_switch
                else:
                    if 'emu_switch' == link_node.get('type'):
                        dst_id = link_node.text
                        temp_switch = case_data.switch_dict[long(dst_id)]
                        emuInterface.Switch = temp_switch
                    elif 'emu_router' == link_node.get('type') or 'emu_ips' == link_node.get('type') or 'emu_firewall' == link_node.get('type'):
                        dst_id = link_node.text
                        dst_interface_id = link_node.get('dst_if')
                        hid_switch_b_name = self.__generate_hid_switch_name(ips.id, emuInterface.id, dst_id, dst_interface_id)
                        if case_data.hid_switch_dict.get(hid_switch_b_name) is None:
                            hid_switch = Switch()
                            hid_switch.ovsbr_name = hid_switch_b_name
                            case_data.hid_switch_id[hid_switch_b_name] = hid_switch
                            emuInterface.Switch = hid_switch
                        else:
                            hid_switch = case_data.hid_switch_dict[hid_switch_b_name]
                            emuInterface.Switch = hid_switch
                    else:
                        logging.error("error:the ips cannot connect to emu_ids, emu_host and emu_server")
                ips.interface_list.insert(emuInterface.id, emuInterface)
            for rule in ips_node.find('rules').findall('rule'):
                ips.rules.append(rule.attrib)
            case_data.ips_dict[ips.id] = ips
        return 0

    # 解析emu_ids的xml，把数据都写在casedata.ids_dict里面，如果程序无误返回0，有错返回-1
    def __parse_ids(self, ids_nodes, case_data):
        for ids_node in ids_nodes:
            ids = Ids()
            for interface_node in ids_node.findall('interface'):
                emuInterface = EmuInterface()
                emuInterface.id = int(interface_node.get('id'))
                emuInterface.boundary = interface_node.get('boundary')
                emuInterface.mac = interface_node.get('mac')
                emuInterface.ip = interface_node.find('ip').get('address')
                emuInterface.mask = interface_node.find('ip').get('netmask')
                emuInterface.gateway = interface_node.find('ip').get('gateway')
                emuInterface.link_type = interface_node.find('link').get('type')
                emuInterface.usage_type = interface_node.find('using_type').text
                link_node = interface_node.find('link')
                if 'emu_switch' == link_node.get('type'):
                    link2side = link_node.text
                    temp_switch = case_data.switch_dict[long(link2side)]
                    emuInterface.Switch = temp_switch
                else:
                    logging.error("error:the ids cannot connect to all devices other than emu_switch")
                ids.interface_list.insert(emuInterface.id, emuInterface)
            for rule in ids_node.find('rules').findall('rule'):
                ids.rules.append(rule.attrib)
            ids.id = long(ids_node.get('id'))
            ids.hypervisor = ids_node.find('hypervisor').get('name')
            case_data.ids_dict[ids.id] = ids
        return 0

