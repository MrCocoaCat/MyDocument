#!/bin/bash

# $1 is the bridge name , $2 is the mirror port
Bridge=$1
Target_port=$2

echo $Target_port | grep "-emu" > /dev/null
if [ $? -ne 0 ]
then
	emu="-emu"
	Target_port=${Target_port}${emu}
fi

IFS=$'\n' 

found=0 # if found the bridge then the flage the follow "Port", untill the next "Bridge"

cmd="sudo ovs-vsctl -- set Bridge $Bridge mirrors=@m"
select_port="remove"
sym=",@"

# get the port names
for name in `ovs-vsctl show`
do
	if [ $found -eq 0 ]  # enter this part when we haven't found the "Bridge" we needed
	then
		echo $name | grep $Bridge >  /dev/null 
		if [ $? -eq 0  ]
		then
#			echo $name
			found=1
		fi
	else                # deal with each "Port"  in the "Bridge" we needed
		echo $name | grep $Bridge > /dev/null           # if this line is the "internal" about, we skip it
		if [ $? -eq 0 ]
		then
			continue
		fi

		echo $name | grep "Port" > /dev/null
		if [ $? -ne 0 ]
		then
			echo $name | grep "Interface" > /dev/null
			if [ $? -ne 0 ]
			then
				echo $name | grep "type:" > /dev/null
				if [ $? -ne 0 ]
				then
					found=0
					break              # finish the "Port" in the "Bridge"
				else
					continue 
#					echo $name
				fi
			else
				continue
#				echo $name
			fi
		else
			# remove the useless characters except the name of the port, 
			# use the name contain "-emu" to create the mirror port
			name=`echo $name | sed 's/"//' | sed 's/"//' | sed 's/Port//' | sed 's/         //' | grep -emu | sed 's/[ ]*$//'`
			echo $name | grep -emu
			if [ $? -eq 0 ]
			then
				#tmp=" −− −−id=@$name get Port $name "
				tmp=" -- --id=@$name get Port $name "
				cmd=${cmd}${tmp}
				
				if [ $name != $Target_port ]
				then
					select_port=${select_port}${sym}${name}
				fi
			fi
		fi
	fi
done

select_port=`echo $select_port | sed 's/remove,//'`

tmp=" -- --id=@m create Mirror name=mymirror select-dst-port=$select_port select-src-port=$select_port output-port=@$Target_port"
cmd=${cmd}${tmp}
echo $cmd
eval `echo $cmd`


#ovs-vsctl -- set Bridge ovsBR1 mirrors=@m \
#-- --id=@veth0 get Port veth0 \
#-- --id=@patch-int get Port patch-int \
#-- --id=@br-tun get Port br-tun \
#-- --id=@m create Mirror name=veth（端口镜像的名字） select-src-port=@br-tun,@patch-int \
#select-dst-port=@br-tun,@patch-int output-port=@veth0
