# -*-coding:utf-8-*-
import sys
import libvirt
from logger.logger import *

class virtualmanager(object):

    __conn = None

    def __init__(self):
        self.conn = virtualmanager.__create_conn()

    @staticmethod
    def __create_conn():
        if virtualmanager.__conn is None:
            try:
                virtualmanager.__conn = libvirt.open('qemu:///system')
            except:
                logging.debug('Failed to open connection to qemu:///system')
        return virtualmanager.__conn


    def vir_create(self,xml_config):
        # xmlconfig = '<domain>........</domain>'
        # virsh create sample.xml
        conn = self.conn
        try:
            dom = conn.createXML(xml_config, 0)
            if dom is None:
                logging.debug('Failed to create a domain from an XML definition.')
            print('Guest ' + dom.name() + ' has booted')
        except Exception,e:
            logging.error("%s : %s" % (Exception, e))


    def vir_pause(self, virname):
        # virsh suspend virname
        dom = self.searchbyname(virname)
        return dom.suspend() == 0


    def vir_resume(self,virname):
        # virsh resume virname
        dom = self.searchbyname(virname)
        return dom.resume() == 0



    def searchbyname(self,domain_name):
        conn = self.conn
        try:
            search_res = conn.lookupByName(domain_name)
            logging.debug("search by name is OK,the domain_name is %s" % (domain_name))
            return search_res
        except:
            logging.debug("failed to find the domain with name %s" %(domain_name))

    def closeconn(self):
        self.conn.close()



    def searchbyid(self,domain_id):
        conn = self.conn
        try:
            search_res = conn.lookupByID(domain_id)
            logging.debug("search by name is OK,the domain_name is %d" % (domain_id))
        except:
            logging.debug("failed to find the domain with name %d" % (domain_id))

    def vir_reboot(self, domain_name):
        dom = self.searchbyname(domain_name)
        return dom.reboot() == 0

    def vir_destroy(self, domain_name):
        dom = self.searchbyname(domain_name)
        return dom.destroy() == 0

