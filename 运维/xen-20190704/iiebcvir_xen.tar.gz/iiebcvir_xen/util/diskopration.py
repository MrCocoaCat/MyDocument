# -*-coding:utf-8-*-
import guestfs

from logger.logger import *


class DiskOperation(object):
    def __init__(self):
        pass

    def create_disk(self, disk, filename, remote_filename):
        try:
            g = guestfs.GuestFS(python_return_dict=True)
            g.disk_create(disk, "qcow2", 1024 * 1024 * 1024)
            g.set_trace(1)
            g.add_drive_opts(disk, readonly=0)
            g.launch()
            devices = g.list_devices()
            assert (len(devices) == 1)
            g.part_disk(devices[0], "gpt")
            partitions = g.list_partitions()
            assert (len(partitions) == 1)
            g.mkfs("ext4", partitions[0])
            g.mount(partitions[0], "/")
            g.upload(filename, remote_filename)
            g.shutdown()
            g.close()
            return 0
        except Exception, e:
            logging.error("%s:%s" % (Exception, e))
            return -1

    def upload_disk(self, disk, filename, remote_filename):
        g = guestfs.GuestFS(python_return_dict=True)
        g.add_drive_opts(disk, readonly=0)
        g.launch()
        try:
            g.mount("/dev/sda1", '/')
            g.upload(filename, remote_filename)
        except Exception, e:
            logging.error("%s:%s" % (Exception, e))
        finally:
            g.umount_all()




# virsh attach-disk 77  '/home/zjl/disk_ntfs.img' 'vda' --live --driver 'qemu' --subdriver 'qcow2' --mode 'shareable' --sourcetype 'file' --targetbus 'virtio'
# virsh detach-disk 76 '/home/zjl/disk1.img'

