from logger.logger import *
import threading

vncport_min = 62000
vncport_cur = 62000
vncport_max = 65000
vncport_lock = threading.Lock()


def getvncport():
    global vncport_cur
    global vncport_max
    global vncport_min
    global vncport_lock
    if vncport_lock.acquire():
        if vncport_cur < vncport_max:
            vncport_cur = vncport_cur + 1
        else:
            vncport_cur = vncport_min + 1
            logging.info("vncport number is empty,so we beggin from min_number")
        vncport_lock.release()
    return vncport_cur
