# -*-coding:utf-8-*-
from ctypes import *


def calling_code():
    test = cdll.LoadLibrary("./")  # /后放C++的.so文件的路径(linux为绝对路径)
    testpy = test.loadFile  # loadFile是C++函数
    testpy.argtype = c_char_p  # 将python传到C++函数中的参数改为char形式,如果是别的类型为c_bool,如果两个参数使用下面注释的方式
    testpy.restype = c_char_p  # 设置返回值的类型
    # encodeFile.argtypes = [c_char_p, c_char_p]
    args = ""  # 向C函数传递的参数
    params = testpy(args)
    return params
