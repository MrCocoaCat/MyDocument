from logger.logger import *
import threading



brno_min = 40000000
brno_cur = 40000000
brno_max = 99999999
br_lock = threading.Lock()

def getbr():
    global brno_cur
    global brno_max
    global brno_min
    global br_lock
    #
    if br_lock.acquire():
        if brno_cur < brno_max:
                brno_cur = brno_cur + 1
        else:
            brno_cur = brno_min + 1
            logging.info("br number is empty,so we beggin from min_number")
        br_lock.release()
    #
    return brno_cur


