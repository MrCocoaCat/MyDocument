# -*-coding:utf-8-*-

import os
from logger.logger import *
import xml.etree.ElementTree as ET

def cisco_router_format(router,xml_routing_file_path,result_network_file_path,result_routing_file_path):
    try:
        interface_list = router.interface_list
        i = 0
        pc_route_interface = ""
        interface_name = []
        configRouter_interface = []
        configRouter_str = ""
        for interface in interface_list:
            name = 'eth%d' % i
            interface_name.append(name)
            i += 1
        n = 0
        count = 0
        for j in range(len(interface_name)):
            pc_route_interface = pc_route_interface + 'f%d/%d=NIO_linux_eth:%s\n' % (n, count, interface_name[j])
            configRouter_str = 'int f%d/%d' % (n, count)
            configRouter_interface.append(configRouter_str)
            count += 1
            if count == 2:
                n += 1
                count = 0
            if n > 6:
                print  u"路由器7200无法提供更多fastethernet接口"
        route_net = """
autostart=True
ghostios=true
sparsemem=true
port=7200
udp=10000
[localhost]
workingdir=/home/route/log
    [[7200]]
    image=/home/route/route_install/c7200-p-mz.123-14.T7.bin
    console=2001
    ram=256
    rom=4
    npe=npe-400
    disk0=64
    disk1=64
    idlepc=0x6090a62c
    confreg=0x2102
    exec_area=64
    mmap=true
    nvram=128
    cnfg=None

    [[router 7200]]
    model=7200
    %s
        """ % pc_route_interface
        route_net_name = result_network_file_path + 'route_7200.net'
        with open(route_net_name, 'w') as f:
            f.write(route_net)
        static = """
#!/usr/bin/expect
set timeout -1
log_file test_automation_static.log
spawn telnet localhost 2001
send "\\r"
expect "Router>"
send "en\\r"
send "\\r"
send "en\\r"
expect "Router#"
send "conf t\\r"
expect "Router(config)#"
        """
        route_ip_set = ""
        change_str = ""
        for i in range(len(router.interface_list)):
            change_str = """
send "%s\\r"
expect "Router(config-if)#"
send "ip address %s %s\\r"
expect "Router(config-if)#"
send "no shutdown\\r"
send "\\r"
expect "Router(config-if)#"
send "exit\\r"
expect "Router(config)#"
                """ % (configRouter_interface[i], router.interface_list[i].ip, router.interface_list[i].mask)
            route_ip_set = route_ip_set + change_str
        tree = ET.parse(xml_routing_file_path)
        root = tree.getroot()
        routings = root.findall('routing')
        declare_network = ""
        for rout in routings:
            if rout.find('routeType').text=="host":
                continue
            if int(rout.find('sourceID').text) == router.id:
                declare_network = declare_network + """
send "ip route %s %s %s\\r"
expect "Router(config)#"
                """ % (rout.find('ip').attrib['network'], rout.find('ip').attrib['netmask'], rout.find('nextHop').text)
        declare_network = declare_network + """
send "end\\r"
expect sleep 3
send "\\r"
interact
        """
        final_route_seting = static + route_ip_set + declare_network
        final_route_seting_filename = result_routing_file_path + '%s.exp' % router.id
        with open(final_route_seting_filename, 'w') as f:
            f.write(final_route_seting)
        return 0

    except Exception, e:
        logging.error('%s: %s' % (Exception, e))
        return -1
