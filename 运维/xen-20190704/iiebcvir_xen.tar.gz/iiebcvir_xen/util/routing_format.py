# -*-coding:utf-8-*-
import os

from logger.logger import *
from IPy import IP
try:
    import xml.etree.cElementTree as ET  # 导入cElementTree解析xml文件
except ImportError:  # 如果没有的话
    import xml.etree.ElementTree as ET  # 导入ElementTree解析xml文件，cElementTree比ElementTree速度要快，占内存更小


# 求最小子网地址 如192.168.0.1/16
def min_subnet_add(ip,mask):
    subnet_obj = IP(ip).make_net(mask)
    subnet_int = subnet_obj.ip
    int_to_ip = lambda x: '.'.join([str(x / (256 ** i) % 256) for i in range(3, -1, -1)])
    res = int_to_ip(subnet_int + 1) + "/" + str(exchange_mask(mask))
    return res

# 子网掩码转位长
def exchange_mask(mask):
    # 计算二进制字符串中 '1' 的个数
    count_bit = lambda bin_str: len([i for i in bin_str if i == '1'])
    # 分割字符串格式的子网掩码为四段列表
    mask_splited = mask.split('.')
    # 转换各段子网掩码为二进制, 计算十进制
    mask_count = [count_bit(bin(int(i))) for i in mask_splited]
    return sum(mask_count)


# 位长转子网掩码
def exchange_maskint(mask_int):
  bin_arr = ['0' for i in range(32)]
  for i in range(mask_int):
    bin_arr[i] = '1'
  tmpmask = [''.join(bin_arr[i * 8:i * 8 + 8]) for i in range(4)]
  tmpmask = [str(int(tmpstr, 2)) for tmpstr in tmpmask]
  return '.'.join(tmpmask)


def cisio_router_format(router, xml_routing_file_path, result_network_file_path,result_routing_file_path):
    try:
        interface_list = router.interface_list
        i = 0
        pc_route_interface = ""
        interface_name = []
        for interface in interface_list:
            name = 'eth%d' % i
            interface_name.append(name)
            i += 1
        for i in range(len(interface_name)):
            if i == 0:
                pc_route_interface = 'f0/0=NIO_linux_eth:%s\n' % interface_name[i]
            elif i < 5:
                pc_route_interface = pc_route_interface + 's1/%d=NIO_linux_eth:%s\n' % (i - 1, interface_name[i])
            elif i < 9:
                pc_route_interface = pc_route_interface + 's2/%d=NIO_linux_eth:%s\n' % (i - 5, interface_name[i])
            else:
                print u"路由器7200无法提供更多接口"
        route_net = """
    autostart=True
    ghostios=true
    sparsemem=true
    port=7200
    udp=10000
    [localhost]
    workingdir=/home/route/log
        [[7200]]
        image=/home/route/route_install/c7200-p-mz.123-14.T7.bin
        console=2001
        ram=256
        rom=4
        npe=npe-400
        disk0=64
        disk1=64
        idlepc=0x6090a62c
        confreg=0x2102
        exec_area=64
        mmap=true
        nvram=128
        cnfg=None

        [[router 7200]]
        model=7200
        %s
    		""" % pc_route_interface
        route_net_name = result_network_file_path + 'route_7200.net'
        with open(route_net_name, 'w') as f:
            f.write(route_net)

        tree = ET.parse(xml_routing_file_path)
        root = tree.getroot()
        routings = root.findall('routing')
        declare_networks = ""
        for rout in routings:
            if int(rout.find("sourceID").text) == router.id:
                declare_network = """
            send "ip route %s %s %s\r"
            expect "Router(config)#"
            				""" % (
                rout.find('ip').get('network'), rout.find('ip').get('netmask'), rout.find('nextHop').text)
                declare_networks = declare_networks + declare_network
            end = """
            send "end\r"
            expect sleep 3
            send "\r"
            interact
            		"""
        static = """
    #!/usr/bin/expect
    set timeout 10
    log_file test_automation_static.log
    spawn telnet localhost 2001
    expect "initial configuration dialog?"
    send "no\r"
    expect sleep 20
    expect "terminate autoinstall?"
    send "yes\r"
    send "\r"
    send "\r"
    expect "Router>"
    send "en\r"
    expect "Router#"
    send "conf t\r"
    expect "Router(config)#"
    		"""
        route_ip_set = ""
        for interface in router.interface_list:
            for i in range(len(router.interface_list)):
                if i == 0:
                    change_str = """
    send "int f0/0\r"
    expect "Router(config-if)#"
    send "ip address %s %s\r"
    expect "Router(config-if)#"
    send "no shutdown\r"
    expect sleep 10
    send "\r"
    expect "Router(config-if)#"
    					""" % (interface.ip, interface.mask)
                    route_ip_set = route_ip_set + change_str
                elif i < 5:
                    change_str = """
    send "int s1/%d\r"
    expect "Router(config-if)#"
    send "ip address %s %s\r"
    expect "Router(config-if)#"
    send "no shutdown\r"
    expect sleep 10
    send "\r"
    expect "Router(config-if)#"
    					""" % (i - 1, interface.ip, interface.mask)
                    route_ip_set = route_ip_set + change_str
                elif i < 9:
                    change_str = """
    send "int s2/%d\r"
    expect "Router(config-if)#"
    send "ip address %s %s\r"
    expect "Router(config-if)#"
    send "no shutdown\r"
    expect sleep 10
    send "\r"
    expect "Router(config-if)#"
    					""" % (i - 5, interface.ip, interface.mask)
                    route_ip_set = route_ip_set + change_str
                else:
                    print u"路由器7200无法提供更多接口"
        route_ip_set = route_ip_set + """
    send "exit\r"
    expect "Router(config)#"
    		"""

        final_route_seting = static + route_ip_set + declare_networks + end
        final_route_seting_filename = result_routing_file_path + '%s.exp' % router.id
        with open(final_route_seting_filename, 'w') as f:
            f.write(final_route_seting)
        return 0
    except Exception, e:
        logging.error('%s: %s' % (Exception, e))
        return -1


# 路由xml转为xorp格式，并放在指定目录
def xorp_router_format(router, xml_routing_file_path, result_file_path):
    try:
        tree = ET.parse(xml_routing_file_path)  # 找到xml文件的位置，并打开
        root = tree.getroot()  # 获取该xml文件的根节点
        routings = root.findall('routing')
        routs = ""
        for rout in routings:
            if rout.find('routeType').text == "host":
                continue
            nextHop = rout.find('nextHop').text
            ip = rout.find('ip').get('network')
            mask = exchange_mask(rout.find('ip').get('netmask'))
            static = """
static {
     route %s/%d {
     next-hop: %s
     }
}
            """ % (ip, mask, nextHop)
            routs = routs + static
        interface_list = router.interface_list
        inters = ""
        i = 0
        for interface in interface_list:
            ip = interface.ip
            mask = exchange_mask(interface.mask)
            name = 'eth%d' % i
            inter = """
interface %s{
 vif %s{
      address %s{
      prefix-length:%d
      }
  }
}
            """ % (name, name, ip, mask)
            inters = inter + inters
            i += 1
        interfaces = """/* $XORP$ */     
interfaces {
%s
}
        """ % inters
        fea = """
fea {
     unicast-forwarding4 {
     disable: false
     }
}
        """
        protocols = """
protocols {
%s
}
        """ % routs
        xorp_file = interfaces + fea + protocols
        xorp_file_name = result_file_path  + '%s.boot' % router.id
        with open(xorp_file_name, 'w') as f:
            f.write(xorp_file)
        return 0
    except Exception, e:
        logging.error('%s: %s' % (Exception, e))
        return -1


def com_router_node_format(router, result_file_path):
    try:
        interfaces = ""
        for inter in router.interface_list[::-1]:
            interface = """
    <interface id="%s" boundary="%s" mac="%s">
      <ip address="%s" netmask="%s" gateway="%s"/>
    </interface>
            """ % (inter.id, inter.boundary, inter.mac, inter.ip, inter.mask, inter.gateway)
            interfaces = interface + interfaces
        xml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
  <emu_router id="%s">
    <name></name>
    <description></description>
    %s
  </emu_router>
</root>
        """ % (router.id, interfaces)
        xmlfile = result_file_path  + '%s.xml' % router.id
        with open(xmlfile, 'w') as f:
            f.write(xml)
        return 0
    except Exception, e:
        logging.error("%s:%s" % (Exception, e))
        return -1


# 创建防火墙的配置文件
def create_firewall_xml(firewall, xml_routing_file_path, result_file_path):
    try:
        tree = ET.parse(xml_routing_file_path)  # 找到xml文件的位置，并打开
        root = tree.getroot()  # 获取该xml文件的根节点
        routings = root.findall('routing')
        # 拼接routes的数据
        routs = ""
        for routing in routings:
            next_hop = routing.find('nextHop').text
            ip = routing.find('ip').get('network')
            mask = routing.find('ip').get('netmask')
            route_type = routing.find('routeType').text
            routing_type = routing.find('type').text
            source_id = routing.find('sourceID').text
            source_ip = routing.find('sourceIP').text
            next_id = routing.find('nextID').text
            rout = """
          <routing>
              <routeType>%s</routeType>
              <type>%s</type>
              <sourceID>%s</sourceID>
              <sourceIP>%s</sourceIP>
              <ip  network="%s" netmask="%s"/>
              <nextID>%s</nextID>
              <nextHop>%s</nextHop>
          </routing> 
            """ % (route_type, routing_type, source_id, source_ip, ip, mask, next_id, next_hop)
            routs = rout + routs
        # 拼接interface里面的数据
        interfaces = ""
        for interface_node in firewall.interface_list[::-1]:
            id = interface_node.id
            boundary = interface_node.boundary
            mac = interface_node.mac
            ip = interface_node.ip
            mask = interface_node.mask
            using_type = interface_node.usage_type
            interface = """
        <interface id="%s" boundary="%s" mac="%s">
          <ip address="%s" netmask="%s"/>
          <using_type>%s</using_type>
        </interface>
            """ % (id, boundary, mac, ip, mask, using_type)
            interfaces = interface + interfaces
        # 拼接rules里面的数据
        rules = ""
        for rule in firewall.rules:
            ruling = """
          <rule id="%s" enable="%s"/>
            """ % (rule.get('id'), rule.get('enable'))
            rules = rules + ruling
        # 拼接portfilter里面的数据
        portfilters = ""
        for portfilter in firewall.portFilter:
            port = portfilter.get("port")
            direction = portfilter.get("direction")
            passing = portfilter.get('pass')
            protocal = portfilter.get("protocal")
            if portfilter is None:
                rule = """
          <rule port="%s" direction="%s" pass="%s"/>
                """ % (port, direction, passing)
            else:
                rule = """
          <rule port="%s" direction="%s" pass="%s" protocal="%s"/>
                """ % (port, direction, passing, protocal)
            portfilters = portfilters + rule
        # 拼接xml文件
        xml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
  <emu_firewall id="%s">
        <name></name>
        <descriptions></descriptions>
        %s
        <rules>
          %s
        </rules>
        <portfilter>
          %s
        </portfilter>
        <routes>
          %s
        </routes>
  </emu_firewall>
</root>
        """ % (firewall.id, interfaces, rules, portfilters, routs)
        file_name = result_file_path  + "%s.xml" % firewall.id
        print xml
        with open(file_name, 'w') as f:
            f.write(xml)
        return 0
    except Exception, e:
        logging.error("%s:%s" % (Exception, e))
        return -1


# 创建ips的xml文件并放入指定目录
def create_ips_xml(ips, result_file_path):
    try:
        interfaces = ""
        for inter in ips.interface_list[::-1]:
            id = inter.id
            boundary = inter.boundary
            mac = inter.mac
            ip = inter.ip
            mask = inter.mask
            using_type = inter.usage_type
            interface = """
        <interface id="%s" boundary="%s" mac="%s">
          <ip address="%s" netmask="%s"/>
          <using_type>%s</using_type>
        </interface>
            """ % (id, boundary, mac, ip, mask, using_type)
            interfaces = interface + interfaces
        rules = ""
        for rule in ips.rules:
            id = rule.id
            enable = rule.enable
            ruling = """
            <rule id="%s" enable="%s"/>
            """ % (id, enable)
            rules = rules + ruling
        xml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
  <emu_ips id="%s">  
        <name></name>
        <description></description>
         %s
         <rules>
           %s
         </rules>
  </emu_ips>
</root>
        """ % (ips.id, interfaces, rules)
        file_name = result_file_path  + "%s.xml" % ips.id
        with open(file_name, 'w') as f:
            f.write(xml)
        return 0
    except Exception, e:
        logging.error("%s:%s" % (Exception, e))
        return -1


# 创建ids的xml文件并放入指定目录
def create_ids_xml(ids, result_file_path):
    try:
        interfaces = ""
        for inter in ids.interface_list[::-1]:
            id = inter.id
            boundary = inter.boundary
            mac = inter.mac
            ip = inter.ip
            mask = inter.mask
            using_type = inter.usage_type
            interface = """
        <interface id="%s" boundary="%s" mac="%s">
          <ip address="%s" netmask="%s"/>
          <using_type>%s</using_type>
        </interface>
                    """ % (id, boundary, mac, ip, mask, using_type)
            interfaces = interface + interfaces
        rules = ""
        for rule in ids.rules:
            id = rule.id
            enable = rule.enable
            ruling = """
          <rule id="%s" enable="%s"/>
                    """ % (id, enable)
            rules = rules + ruling
        xml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
  <emu_ids id="%s">
        <name></name>
        <description></description>
         %s
        <rules>
          %s
        </rules>
  </emu_ids>
</root>
        """ % (ids.id, interfaces, rules)
        file_name = result_file_path + '%s.xml' % ids.id
        with open(file_name, 'w') as f:
            f.write(xml)
        return 0
    except Exception, e:
        logging.error("%s:%s" % (Exception, e))
        return -1