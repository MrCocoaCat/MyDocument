# -*-coding:utf-8-*-
import threading

ip_min = 199
ip_cur = 199
ip_max = 250

mac_min = 0
mac_cur = 0
mac_max = 10001


def get_ip():
    ip_pre = "192.168.125."
    global ip_min
    global ip_cur
    global ip_max
    if ip_cur < ip_max:
        ip_cur = ip_cur + 1
    else:
        ip_cur = ip_min + 1
    ip_add = ip_pre + str(ip_cur)
    return ip_add


def get_mac():
    mac_pre = "12:34:56:00:"

    global mac_max
    global mac_min
    global mac_cur

    if mac_cur < mac_max:
        mac_cur = mac_cur + 1
    else:
        mac_cur = mac_min + 1

    mac_one = mac_cur % 10
    mac_two = (mac_cur/10) % 10
    mac_three = (mac_cur/100) % 10
    mac_four = (mac_cur/1000) % 10
    mac_tail = str(mac_four) + str(mac_three) + ":" + str(mac_two) + str(mac_one)
    mac_add = mac_pre + mac_tail
    return mac_add



if __name__ == "__main__":
    mac1 = get_mac()
    mac2 = get_mac()
    mac3 = get_mac()
    mac4 = get_mac()
    mac5 = get_mac()
    mac6 = get_mac()
    mac7 = get_mac()
    mac8 = get_mac()
    mac9 = get_mac()
    mac10 = get_mac()
    mac11 = get_mac()
    mac12 = get_mac()
    print mac10, mac11, mac12

