
def hostxmlgen(name, mem, vcpu, imgpath, interfaces, vncport):

    basexml = '''<domain type='kvm'>
	<name>%s</name> 
	<memory>%d</memory> 
	<currentMemory>%d</currentMemory> 
	<vcpu>%d</vcpu>
	<os>
		<type arch='x86_64' machine='pc'>hvm</type>
		<boot dev='hd'/>     
	</os>
	<features>
		<acpi/>
		<apic/>
		<pae/>
	</features>
	<clock offset='localtime'/>
	<on_poweroff>destroy</on_poweroff>
	<on_reboot>restart</on_reboot> 
	<on_crash>destroy</on_crash>
	<devices>
		<emulator>/usr/libexec/qemu-kvm</emulator>
		<disk type='file' device='disk'>
		<driver name='qemu' type='qcow2'/> 
			<source file='%s'/>
			<target dev='hda' bus='ide'/>
		</disk>
'''%(name,mem,mem,vcpu,imgpath)

    interfacesxml = ""
    for interface in interfaces:
        print "ovsbr ---------"
        print hasattr(interface.Switch,"ovsbr_name")
        if hasattr(interface.Switch,"ovsbr_name"):
            interfacexml = '''<interface type='bridge'>
                        <mac address='%s'/>
                        <source bridge='%s'/>
                <virtualport type='openvswitch'/>
                </interface>
        ''' %(interface.mac, interface.Switch.ovsbr_name)
        else:
            ovs_br = "single"
            interfacexml = '''<interface type='bridge'>
                            <mac address='%s'/>
                            <source bridge='%s'/>
                    <virtualport type='openvswitch'/>
                    </interface>
            ''' % (interface.mac, ovs_br)
        interfacesxml = interfacesxml + interfacexml

    vncxml = '''<input type='mouse' bus='ps2'/>
        <input type='tablet' bus='usb'/>
        <graphics type='vnc' port='%s' autoport='no' listen='0.0.0.0' keymap='en-us'/>
        </devices>
        </domain> ''' %(vncport)
    sumxml = basexml + interfacesxml + vncxml
    return sumxml







def wintenhostxmlgen(name, mem,  imgpath, interfaces, vncport):

    basexml = '''<domain type='kvm'>
	<name>%s</name> 
	<memory>%d</memory> 
	<currentMemory>%d</currentMemory> 
    <cpu mode='host-passthrough'/>
	<os>
		<type arch='x86_64' machine='pc'>hvm</type>
		<boot dev='hd'/>     
	</os>
	<features>
		<acpi/>
		<apic/>
		<pae/>
	</features>
	<clock offset='localtime'/>
	<on_poweroff>destroy</on_poweroff>
	<on_reboot>restart</on_reboot> 
	<on_crash>destroy</on_crash>
	<devices>
		<emulator>/usr/libexec/qemu-kvm</emulator>
		<disk type='file' device='disk'>
		<driver name='qemu' type='qcow2'/> 
			<source file='%s'/>
			<target dev='hda' bus='ide'/>
		</disk>
'''%(name,mem,mem,imgpath)

    interfacesxml = ""
    print len(interfaces)
    if len(interfaces) is not 0:
        for interface in interfaces:
            ovsbr = "vs_internet"
            interfacexml = '''<interface type='bridge'>
                            <mac address='%s'/>
                            <source bridge='%s'/>
                    <virtualport type='openvswitch'/>
                    </interface>
            ''' %(interface.mac, interface.Switch.ovsbr_name)
            interfacesxml = interfacesxml + interfacexml

    vncxml = '''<input type='mouse' bus='ps2'/>
        <input type='tablet' bus='usb'/>
        <graphics type='vnc' port='%s' autoport='no' listen='0.0.0.0' keymap='en-us'/>
        </devices>
        </domain> ''' %(vncport)
    sumxml = basexml + interfacesxml + vncxml
    return sumxml


def xenhostgen(name, mem, vcpu, filepath,imgpath, interfaces, vncport):
    vcpu = 4
    mem =4096000
    basexml = '''<domain type='xen'>
    	<name>%s</name> 
    	<memory>%d</memory> 
    	<currentMemory>%d</currentMemory> 
    	<vcpu placement='static'>%d</vcpu>
    	<os>
    		<type arch='x86_64' machine='xenfv'>hvm</type>
    		<loader type='rom'>/usr/lib/xen-4.6/boot/hvmloader</loader>
    		<boot dev='hd'/>     
    	</os>
    	<features>
    		<acpi/>
    		<apic/>
    		<pae/>
    	</features>
    	<clock offset='localtime'/>
    	<on_poweroff>destroy</on_poweroff>
    	<on_reboot>restart</on_reboot> 
    	<on_crash>destroy</on_crash>
    	<devices>
    		<emulator>/usr/bin/qemu-system-i386</emulator>
    		<disk type='file' device='disk'>
    		<driver name='qemu' type='qcow2'/> 
    		<source file='%s'/>
    		<backingStore/>
    		<target dev='hda' bus='ide'/>
    		<address type='drive' controller='0' bus='0' target='0' unit='0'/>
    		</disk>
    ''' % (name, mem, mem, vcpu, imgpath)

    interfacesxml = ""
    for interface in interfaces:
        print "ovsbr ---------"
        print hasattr(interface.Switch, "ovsbr_name")
        if hasattr(interface.Switch, "ovsbr_name"):
            interfacexml = '''<interface type='bridge'>
                            <mac address='%s'/>
                            <source bridge='%s'/>
                    <script path='/etc/xen/scripts/vif-openvswitch'/>
                    </interface>
            ''' % (interface.mac, interface.Switch.ovsbr_name)
        else:
            ovs_br = "single"
            interfacexml = '''<interface type='bridge'>
                                <mac address='%s'/>
                                <source bridge='%s'/>
                        <script path='/etc/xen/scripts/vif-openvswitch'/>
                        </interface>
                ''' % (interface.mac, ovs_br)
        interfacesxml = interfacesxml + interfacexml

    vncxml = '''
            <serial type='pty'>
            <target port='0'/>
            </serial>
            <console type='pty'>
            <target type='serial' port='0'/>
            </console>
            <input type='mouse' bus='ps2'/>
            <input type='tablet' bus='usb'/>
            <graphics type='vnc' port='%s' autoport='no' listen='0.0.0.0' keymap='en-us'/>
            </devices>
            </domain> ''' % (vncport)
    sumxml = basexml + interfacesxml + vncxml
    xmlfile = filepath + '%s.xml' % name
    with open(xmlfile, 'w') as f:
        f.write(sumxml)
    return sumxml




