import os
from logger.logger import *
import util.globaldata as gl

def create_dhcp_server_envir(switch):

    switch_name = switch.ovsbr_name
    nsp_port = "nsp_port" + switch_name[8:13:]
    os_port = "os_port" + switch_name[8:13:]
    nsp_name = "nsp_name" + switch_name[8:13:]
    status = 1

    try:
        os.popen("ip netns add %s" %nsp_name)
        logging.info("ip netns add %s" %nsp_name)
        os.popen("ip link add %s type veth peer name %s" %(nsp_port, os_port))
        logging.info("ip link add %s type veth peer name %s" %(nsp_port, os_port))
        os.popen("ip link set %s netns %s" %(nsp_port, nsp_name))
        logging.info("ip link set %s netns %s" %(nsp_port, nsp_name))
        tmp = os.popen("ifconfig %s up" % os_port)
        logging.info("ifconfig %s up" % os_port)
        logging.info("%s" % tmp)
        os.popen("ovs-vsctl add-port %s %s" %(switch_name,os_port))
        logging.info("ovs-vsctl add-port %s %s" %(switch_name,os_port))

        os.popen("ip netns exec %s ip link set dev lo up" % nsp_name)
        logging.info("ip netns exec %s ip link set dev lo up" % nsp_name)
        os.popen("ip netns exec %s ip link set dev %s up" %(nsp_name, nsp_port))
        logging.info("ip netns exec %s ip link set dev %s up" %(nsp_name, nsp_port))
    except Exception,e:
        logging.error("%s,%s" %(Exception,e))
        status = 0
        nsp_name = None
        os_port = None

    return status,nsp_name,nsp_port