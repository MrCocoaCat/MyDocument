# -*-coding:utf-8-*-
import os

from logger.logger import *

try:
    import guestfs
except ImportError as e:
    logging.error("error:%s" % e)

class FileOperations(object):

    def __init__(self):
        pass

    def upload_2_file(self, disk, filename1, remote_filename1, filename2, remote_filename2):
        try:
            os.path.exists(disk)
        except:
            logging.error("error:disk is not found")
        try:
            f = open(filename1)
            f.close()
        except IOError:
            logging.error("File is not accessible")
        try:
            g = guestfs.GuestFS(python_return_dict=True)
            g.add_drive_opts(disk, readonly=0)
            g.launch()
            roots = []
            try:
                roots = g.inspect_os()
            except Exception, e:
                logging.error("%s : %s" % (Exception, e))

            if len(roots) == 0:
                roots.append("/dev/sda1")
            g.mount(roots[0], '/')
            try:
                g.upload(filename1, remote_filename1)
                g.upload(filename2, remote_filename2)
            except Exception, e:
                logging.error("%s : %s" % (Exception, e))
            g.umount_all()
            return 0
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
            return -1

    def upload_file(self, disk, filename, remotefilename):
        try:
            os.path.exists(disk)
        except:
            logging.error("error:disk is not found")
        try:
            f = open(filename)
            f.close()
        except IOError:
            logging.error("File is not accessible")
        try:
            g = guestfs.GuestFS(python_return_dict=True)
            g.add_drive_opts(disk, readonly=0)
            g.launch()
            roots = g.inspect_os()
            if len(roots) == 0:
                raise ("inspect_vm: no operating systems found")
            g.mount(roots[0], '/')
            try:
                g.upload(filename, remotefilename)
            except Exception, e:
                logging.error("%s : %s" % (Exception, e))
            g.umount_all()
            return 0
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
            return -1
