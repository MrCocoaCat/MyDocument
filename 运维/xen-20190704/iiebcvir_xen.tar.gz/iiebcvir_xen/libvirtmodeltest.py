from libvirtmodel.libvirtfuc import virtualmanager
from virxmlgen.virxml import *

xmlsample = hostxmlgen()
test = virtualmanager()

test.vir_create(xmlsample)

test.searchbyname("route2")

test.searchbyid(2)
print "print 1 and pause the instance"

a = raw_input().split("")[0]
int(a)
if a is 1:
    test.vir_pause("route2")
print "print 2 and resume the instance"

a = raw_input().split("")[0]
int(a)

if a is 2:
    test.vir_resume("route2")
