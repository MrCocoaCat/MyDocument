for record in $(ovs-vsctl show | grep Bridge | awk '{print $2}' | sed 's/\"//g')
do
       sudo ovs-vsctl del-br $record;
    done
