# -*-coding:utf-8-*-
import os

from logger.logger import *
from dao.dbcon import DB
from conf.config import ConfParser

db = DB()
# ps aux | pidof dnsmasq | xargs kill -9 删除进程
conf = ConfParser()
path = conf.get("DHCP", "DhcpPath")


class AssignIp(object):
    def __init__(self):
        pass

    def openmasq(self, casedata, switch_id):
        try:
            switch = casedata.switch_dict[switch_id]
            name = switch.ovsbr_name
            linkto_list = switch.linkto_interface_list
            folder = path + name + "/"
            judge1 = os.path.exists(folder)
            if not judge1:
                os.makedirs(folder)
                logging.info('Folder %s creation success' % folder)
            else:
                logging.info('Folders %s already exist' % folder)
            conf = folder + '%s.conf' % name
            pid = folder + "%s.pid" % name
            data = '''
                no-hosts
                no-resolv
                interface=%s
                dhcp-lease-max=256
                except-interface=lo
                bind-interfaces
                log-facility=/tmp/dnsmasq.log
                log-async=10
            ''' % name
            i = 0
            dhcpsum = ""
            for instance in linkto_list:
                if instance[1] != 0:
                    dhcp = """
                dhcp-range=set:tag%d,%s,%s,infinite
                dhcp-host=%s,%s
                dhcp-option=tag:tag%d,option:router,%s
                    """ % (i, instance[0].ip, instance[0].ip, instance[0].mac, instance[0].ip, i, instance[0].gateway)
                    i += 1
                    dhcpsum = dhcpsum + dhcp
                    confstr = data + dhcpsum
                    with open(conf, 'w') as f:
                        f.write(confstr)
                    dhcppathlist = os.popen('which dnsmasq').readlines()
                    dhcppath = dhcppathlist[0].split('\n')[0]
                    cmd = '%s --dhcp-leasefile=%s --conf-file=%s' % (dhcppath, pid, conf)
                    os.system(cmd)
                    return 0
                else:
                    logging.error('error:these devices do not need to assign ip')

        except Exception, e:
            logging.error("%s:%s" % (Exception, e))
            return -1

    def closemasq(self):
        cmd = 'ps aux | pidof dnsmasq | xargs kill -9'
        res = os.system(cmd)
        return res

