from logger.logger import *
import os
from util.getbr import *



# the function is for common ovs create
def common_ovs_create(case_data, dbqueryobj):
    switches = case_data.switch_dict
    logging.info("br's number is %d" % len(switches))
    for k, switch in switches.items():
        if switch is not None:
            ovsname = "ovsbr" + str(getbr())
            switch.ovsbr_name = ovsname
            try:
                os.popen("ovs-vsctl add-br %s" % switch.ovsbr_name)
                os.popen("ifconfig %s up" % switch.ovsbr_name)

                # add peer

                dbqueryobj.saveVSwitchInfo(switch)
            except Exception, e:
                logging.error("%s : %s" %(Exception,e))
                errmsg = "br %s create failed" % switch


# the function is for  hidden ovs creating
def hidden_ovs_create(case_data):
    hid_switches = case_data.hid_switch_dict
    logging.info("hidden br's number is %d" % len(hid_switches))
    for k, hid_switch in hid_switches.items():
        if hid_switch is not None:
            try:
                hid_switch.ovsbr_name = "hidbr" + hid_switch.ovsbr_name[0:10:]
                os.popen("ovs-vsctl add-br %s" % hid_switch.ovsbr_name)
                os.popen("ifconfig %s up" % hid_switch.ovsbr_name)
            except Exception, e:
                logging.error("%s : %s" % (Exception, e))
                errmsg = "br %s create failed" % hid_switch


# subnet assign
def subnet_assign(xml_parse, path, case_data):
    xml_parse.parse_xml_subnet(path, case_data)
    subnet_dict = case_data.subnet_dict
    print len(subnet_dict)

    for k, subnet in subnet_dict.items():
        print k
        if subnet.need_dhcp_server():
            res_status = subnet.start_dhcp_server()
            if res_status is 0:
                logging.info("assign ip success")
            else:
                logging.error("assign ip failed")