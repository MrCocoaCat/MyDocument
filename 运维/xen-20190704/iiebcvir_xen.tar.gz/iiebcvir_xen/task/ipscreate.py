from logger.logger import *
import os
from util.getvnc import *
from util.routing_format import *
from util.virxml import *
from util.fileupload import FileOperations

def ips_create(case_data, conf,  messagedata, vir_manager,dbqueryobj):
    basedir = conf.get("EMU", "CaseFilePath")
    CaseId = messagedata["caseid"] #caseid
    fulldir = basedir + CaseId + "/"
    fullimgdir = fulldir + "diskfile/"
    config_path = fulldir + "configfile/"
    ips_hosts = case_data.ips_dict
    ips_names = []
    for k, ips in ips_hosts.items():
        # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
        vm_template_path = "UB_IPS_1004_i386.img"
        print vm_template_path
        vnc_no = getvncport()
        path_pre = conf.get("EMU", "TemplateImgFilePre")
        path = path_pre + vm_template_path  # 基础模板路径
        name = "IPS_" + str(ips.id)
        vnc_no = getvncport()
        # 查找网卡绑定的对应网桥
        eth_brs = ips.interface_list
        # 把 node 写进数据库
        ips.nodeBName = name
        dbqueryobj.saveVGuestInfo(instance)
        ips_names.append(name)
        fullpath = fullimgdir + name  # 增量镜像路径
        if path is None:
            pass
        else:
            os.popen("qemu-img create -b %s -f qcow2 %s" % (path, fullpath))
            # 生成配置文件 并且挂载到增量镜像上去
            ips_get_status = create_ips_xml(ips, config_path)
            IPS_full_path = config_path + str(ips.id) + ".xml"
            remoteconfigdir = conf.get("EMU", "IPSConfigDir")
            file_utl = FileOperations()
            upload_status = file_utl.upload_file(fullpath, IPS_full_path, remoteconfigdir)

            res_xml = hostxmlgen(name, int(ips.memory_size) * 1024, int(ips.vcpu_no), fullpath, eth_brs,
                                 str(vnc_no))
            print res_xml
            vir_manager.vir_create(res_xml)

        for k, ips in ips_hosts.items():
            if vir_manager.searchbyname(ips.nodeBName):
                logging.info("the %s has been build" % (ips.nodeBName))