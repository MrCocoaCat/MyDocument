from logger.logger import *
import os
from util.getvnc import *
from util.routing_format import *
from util.virxml import *
from util.fileupload import FileOperations


def firewall_create(case_data, conf,  messagedata, vir_manager,dbqueryobj):
    basedir = conf.get("EMU", "CaseFilePath")
    CaseId = messagedata["caseid"] #caseid
    fulldir = basedir + CaseId + "/"
    fullimgdir = fulldir + "diskfile/"
    config_path = fulldir + "configfile/"
    firewall_hosts = case_data.firewall_dict
    for k, firewall in firewall_hosts.items():
        # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
        vm_template_path = "UB_FW_1004_i386.img"
        print vm_template_path
        vnc_no = getvncport()
        path_pre = conf.get("EMU", "TemplateImgFilePre")
        path = path_pre + vm_template_path  # 基础模板路径
        name = "FIREWALL_" + str(firewall.id)
        vnc_no = getvncport()
        # 查找网卡绑定的对应网桥
        eth_brs = firewall.interface_list
        # 把 node 写进数据库
        firewall.nodeBName = name
        dbqueryobj.saveVGuestInfo(firewall)
        fullpath = fullimgdir + name  # 增量镜像路径
        if path is None:
            pass
        else:
            os.popen("qemu-img create -b %s -f qcow2 %s" % (path, fullpath))

            firewall_xml_path = messagedata["define"]["rfile"]
            firewall_xml_path = conf.get("EMU", "XMLFilePathPre") + firewall_xml_path + str(firewall.id) + ".xml"

            firewall_get_status = create_firewall_xml(firewall, firewall_xml_path, config_path)
            firewall_full_path = config_path + str(firewall.id) + ".xml"
            remoteconfigdir = conf.get("EMU", "FirewallConfigDir")
            file_utl = FileOperations()
            upload_status = file_utl.upload_file(fullpath, firewall_full_path, remoteconfigdir)

            res_xml = hostxmlgen(name, int(firewall.memory_size) * 1024, int(firewall.vcpu_no), fullpath, eth_brs,
                                 str(vnc_no))
            print res_xml
            vir_manager.vir_create(res_xml)

    for k, firewall in firewall_hosts.items():
        if vir_manager.searchbyname(firewall.nodeBName):
            logging.info("the %s has been build" % (firewall.nodeBName))