from logger.logger import *
from util.getvnc import *
import os
from util.fileupload import FileOperations
from util.routing_format import *
from util.virxml import *


def router_create(case_data, conf,  messagedata, vir_manager,dbqueryobj):
    router_hosts = case_data.router_dict
    router_names = []
    basedir = conf.get("EMU", "CaseFilePath")
    CaseId = messagedata["caseid"] #caseid
    fulldir = basedir + CaseId + "/"
    fullimgdir = fulldir + "diskfile/"
    if not os.path.exists(fullimgdir):
        os.makedirs(fullimgdir)

    for k, router_host in router_hosts.items():
        # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
        vm_template_path = "UB_Router_1004_i386.img"
        print vm_template_path
        path_pre = conf.get("EMU", "TemplateImgFilePre")
        path = path_pre + vm_template_path  # 基础模板路径
        name = "ROUTER_" + str(router_host.id)
        vnc_no = getvncport()
        # 查找网卡绑定的对应网桥
        eth_brs = router_host.interface_list
        # 把 node 写进数据库
        router_host.nodeBName = name
        dbqueryobj.saveVGuestInfo(router_host)
        router_names.append(name)
        fullpath = fullimgdir + name  # 增量镜像路径

        if path is None:
            logging.error("The base img is not exsits")
        else:
            os.popen("qemu-img create -b %s -f qcow2 %s" % (path, fullpath))
            logging.info("create the increment img")
            # 生成路由xorp配置文件，并且放到相应的目录下
            fulldir = basedir + CaseId + "/"
            config_path = fulldir + "configfile/"  # 用于存放节点目录
            if not os.path.exists(config_path):
                os.makedirs(config_path)

            xorp_xml_path = messagedata["define"]["rfile"]
            xorp_xml_path = conf.get("EMU", "XMLFilePathPre") + xorp_xml_path + str(router_host.id) + ".xml"
            print xorp_xml_path
            xorp_gen_res = xorp_router_format(router_host, xorp_xml_path, config_path)
            if xorp_gen_res is 0:
                logging.info("The task of generating of the router's file succeed")
                # xorp_full_path = config_path + str(router_host.id) + ".boot"
            else:
                logging.error("The task of generating of  the router's file failed")
            # 生成路由信息配置文件，并且放到相应目录下
            # 专用路由 1.创建增量镜像，查询数据库，根据templateid，获取文件名(像普通主机一样)
            #
            # 调用凯宾的专用函数,生成文件
            # 如果
            xorp_full_path = config_path + str(router_host.id) + ".boot"
            router_node_gen = com_router_node_format(router_host, config_path)  # 根据是否为专用还是普通路由，上传文件
            if router_node_gen is 0:
                logging.info("The task of generating of the router's node info file succeed")
                router_node_path = config_path + str(router_host.id) + ".xml"
            else:
                logging.error("The task of generating of the router's node info file succeed")

            # 将生成好的路由文件上传到远程路径下
            remotexorpdir = conf.get("EMU", "RouterXorpDir")
            remoteconfigdir = conf.get("EMU", "RouterConfigDir")
            file_utl = FileOperations()
            upload_status = file_utl.upload_2_file(fullpath, xorp_full_path, remotexorpdir, router_node_path,
                                                   remoteconfigdir)
            if upload_status is 0:
                logging.info("router file upload succeed")
            else:
                logging.info("router file upload failed")

            res_xml = hostxmlgen(name, int(router_host.memory_size) * 1024, int(router_host.vcpu_no), fullpath,
                                 eth_brs, str(vnc_no))
            print res_xml
            vir_manager.vir_create(res_xml)

        for key, rou_host in router_hosts.items():
            if vir_manager.searchbyname(rou_host.nodeBName):
                logging.info("the %s has been build" % rou_host.nodeBName)