import  util.globaldata as gl

def mod1():
    gl.set_value("aa",2)