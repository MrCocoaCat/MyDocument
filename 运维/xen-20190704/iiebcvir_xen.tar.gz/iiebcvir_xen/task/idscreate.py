from logger.logger import *
import os
from util.getvnc import *
from util.routing_format import *
from util.virxml import *
from util.fileupload import FileOperations


def ids_create(case_data, conf,  messagedata, vir_manager,dbqueryobj):
    basedir = conf.get("EMU", "CaseFilePath")
    CaseId = messagedata["caseid"] #caseid
    fulldir = basedir + CaseId + "/"
    fullimgdir = fulldir + "diskfile/"
    config_path = fulldir + "configfile/"
    if not os.path.exists(fullimgdir):
        os.makedirs(fullimgdir)
    ids_hosts = case_data.ids_dict
    for k, ids in ids_hosts.items():
        # vm_template_path = dbqueryobj.getVMTemplate(117)  # get template path
        vm_template_path = "UB_IDS_1004_i386.img"
        print vm_template_path
        vnc_no = getvncport()
        path_pre = conf.get("EMU", "TemplateImgFilePre")
        path = path_pre + vm_template_path  # 基础模板路径
        name = "IDS_" + str(ids.id)
        vnc_no = getvncport()
        # 查找网卡绑定的对应网桥
        eth_brs = ids.interface_list
        # 把 node 写进数据库
        ids.nodeBName = name
        dbqueryobj.saveVGuestInfo(ids)

        fullpath = fullimgdir + name  # 增量镜像路径
        if path is None:
            pass
        else:
            os.popen("qemu-img create -b %s -f qcow2 %s" % (path, fullpath))

            ids_get_status = create_ids_xml(ids, config_path)
            IDS_full_path = config_path + str(ids.id) + ".xml"
            remoteconfigdir = conf.get("EMU", "IDSConfigDir")
            file_utl = FileOperations()
            upload_status = file_utl.upload_file(fullpath, IDS_full_path, remoteconfigdir)

            res_xml = hostxmlgen(name, int(ids.memory_size) * 1024, int(ids.vcpu_no), fullpath, eth_brs,
                                 str(vnc_no))
            print res_xml
            vir_manager.vir_create(res_xml)