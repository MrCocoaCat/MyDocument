from logger.logger import *
import os
from util.getvnc import *
from util.virxml import *


# 2. 创建主机实例
def instance_create(case_data,conf,messagedata,vir_manager,dbqueryobj):

    instances = case_data.virhost_dict
    basedir = conf.get("EMU","CaseFilePath")
    CaseId = messagedata["caseid"] #caseid
    fulldir = basedir + CaseId + "/"
    fullimgdir = fulldir + "diskfile/"
    if not os.path.exists(fullimgdir):
        os.makedirs(fullimgdir)
    instance_names = []

    for k, instance in instances.items():  #获取主机实例信息，进行创建
        vm_template_path = dbqueryobj.getVMTemplate(instance.templateId) # get template path
        print vm_template_path
        path_pre = conf.get("EMU","TemplateImgFilePre")
        path = path_pre + vm_template_path
        name = instance.osType + "_" + str(instance.id)
        fullpath = fullimgdir + name  # 增量镜像目录
        vnc_no = getvncport()
        print vnc_no
        #查找网卡绑定的对应网桥
        eth_brs = instance.interface_list
        #把 node 写进数据库
        instance.nodeBName = name
        dbqueryobj.saveVGuestInfo(instance)
        instance_names.append(name)

        if path is None:
            pass
        else:
            os.popen("qemu-img create -b %s -f qcow2 %s" %(path,fullpath))
        res_xml = hostxmlgen(name,int(instance.memory_size)*1024,int(instance.vcpu_no),fullpath,eth_brs,str(vnc_no))
        print res_xml
        vir_manager.vir_create(res_xml)

    # 查看实例是否正确创建
    for k, instance in instances.items():
        if vir_manager.searchbyname(instance.nodeBName):
            logging.info("the %s has been build" %(instance.nodeBName))
            errmsg = errmsg + "%s create successful" % instance.nodeBName
        else:
            errmsg = errmsg + "%s create failed" % instance.nodeBName