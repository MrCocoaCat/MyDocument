# -*-coding:utf-8-*-
import stomp
import time
from conf.config import ConfParser


class MQSender(object):
    def __init__(self, server_ip, server_port):
        conf = ConfParser()
        self.server_ip = conf.get("MQ","MQServerip")
        self.server_port = 61613
        self.conn = None


    def send_msg(self, topic, msg):
        self.conn = stomp.Connection([(self.server_ip, self.server_port)],auto_content_length=False)  # for send TextMessage do not set header_length
        self.conn.start()
        self.conn.connect('admin', 'admin', wait=True)
        self.conn.send(body=msg,  destination='/topic/' + topic, ack="auto")
        self.conn.disconnect()

    def __del__(self):
        self.conn.disconnect()