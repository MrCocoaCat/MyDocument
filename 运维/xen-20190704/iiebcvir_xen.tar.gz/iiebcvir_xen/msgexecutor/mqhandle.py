# -*-coding:utf-8-*-
import stomp
import time
from logger.logger import *
from excutor.factory import ActionFactory
import threading
import json


class MyListener():
    def __init__(self, conn):
        self.conn = conn
        # self.headers = headers

    def on_error(self, headers, message):
        logging.error('received an error %s' % message)

    def on_message(self, headers, message):
        # for k, v in headers.iteritems():
            # logging.info('header: key %s , value %s' % (k, v))
        # logging.info('received message\n %s' % message)
        try:
            msg_data = json.loads(message)
            logging.info('received message\n %s' % message)
        except Exception, e:
            logging.error("%s : %s" % (Exception, e))
        factory = ActionFactory()
        vir_action = factory.getfactory(msg_data["name"])
        try:
            thread = threading.Thread(target=vir_action.action, args=(message,))
            thread.setDaemon(True)
            thread.start()
            thread.join()
        except Exception,e:
            logging.error("%s : %s" % (Exception, e))



    def on_disconnected(self):
        """
        Called by the STOMP connection when a TCP/IP connection to the
        STOMP server has been lost.  No messages should be sent via
        the connection until it has been reestablished.
        """
        pass

    def on_connecting(self, host_and_port):
        """
        Called by the STOMP connection once a TCP/IP connection to the
        STOMP server has been established or re-established. Note that
        at this point, no connection has been established on the STOMP
        protocol level. For this, you need to invoke the "connect"
        method on the connection.

        \param host_and_port a tuple containing the host name and port
        number to which the connection has been established.
        """
        pass

    def on_connected(self, headers, body):
        """
        Called by the STOMP connection when a CONNECTED frame is
        received, that is after a connection has been established or
        re-established.

        \param headers a dictionary containing all headers sent by the
        server as key/value pairs.

        \param body the frame's payload. This is usually empty for
        CONNECTED frames.
        """
        pass

    def on_heartbeat_timeout(self):
        """
        Called by the STOMP connection when a heartbeat message has not been
        received beyond the specified period.
        """
        pass

    def on_receipt(self, headers, body):
        """
        Called by the STOMP connection when a RECEIPT frame is
        received, sent by the server if requested by the client using
        the 'receipt' header.

        \param headers a dictionary containing all headers sent by the
        server as key/value pairs.

        \param body the frame's payload. This is usually empty for
        RECEIPT frames.
        """
        pass

