# -*-coding:utf-8-*-
import stomp
import time
from logger.logger import *
from msgexecutor.mqhandle import MyListener


class MQReceiverByTopic(object):

    def __init__(self, mq_ip,mq_port):
        self.mq_ip = mq_ip
        self.mq_port = mq_port
        self.conn = None


    def subscribe_topic(self, topic):
        self.conn = stomp.Connection([(self.mq_ip, self.mq_port)])
        self.conn.set_listener('', MyListener(self.conn))
        self.conn.start()
        self.conn.connect('admin', 'admin', wait=True)

        self.conn.subscribe(destination='/topic/' + topic, id=1, ack='auto')
        while True:
            pass

    def receive_always(self):
        while self.conn.is_connected():
            pass
    def receive_discon(self):
        self.conn.disconnect()