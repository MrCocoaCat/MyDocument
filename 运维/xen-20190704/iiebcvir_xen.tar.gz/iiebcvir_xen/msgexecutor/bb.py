import  util.globaldata as gl

def mod2():
    a = gl.get_value("aa")
    print a