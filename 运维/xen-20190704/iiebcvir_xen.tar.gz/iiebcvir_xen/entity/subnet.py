# -*-coding:utf-8-*-
import os

from logger.logger import *
from conf.config import ConfParser
from util.dhcputil import *
from util.routing_format import *


conf = ConfParser()
path = conf.get("DHCP", "DhcpPath")


class Subnet(object):
    def __init__(self):
        self.id = 0
        # key: ovsbr_name
        self.switch_dict = {}
        self.interface_list = []  # (EmuInterface_Object, need_DHCP_ip)
        self.ipbase = ""
        self.ipmask = ""
        self.gateway = ""

    def is_switch_exist(self, ovsbr_name):
        if len(self.switch_dict) == 0:
            return False
        else:
            if self.switch_dict.get(ovsbr_name) is None:
                return False
            else:
                return True

    def need_dhcp_server(self):
        if len(self.switch_dict) == 0:
            return False
        if len(self.interface_list) == 0:
            return False
        else:
            for interface_tup in self.interface_list:
                if interface_tup[1] > 0:
                    return True
        return False

    def get_nspname(self):
        switch = sorted(self.switch_dict.items())[0][1]
        switch_name = switch.ovsbr_name
        nsp_name = "nsp_name" + switch_name[8:13:]
        return nsp_name

    def start_dhcp_server(self):
        try:
            # 从self.switch_dict里边任意选一个switch

            switch = sorted(self.switch_dict.items())[0][1]
            # 调用陈宇的接口  1)创建用于启动dhcp服务的port 2）设置该port严格的ACL 返回port的名字
            nsp_status,nsp_name,nsp_port = create_dhcp_server_envir(switch)
            #为端口分配ip
            if nsp_port is not None:
                res_ip = min_subnet_add(self.ipbase, self.ipmask)
            os.popen("ip netns exec %s ip address add %s dev %s " % (nsp_name, res_ip, nsp_port))
            logging.info("ip netns exec %s ip address add %s dev %s " % (nsp_name, res_ip, nsp_port))
            # 启动dnsmasq进程

            linkto_list = self.interface_list
            folder = path + nsp_port + "/"
            judge1 = os.path.exists(folder)
            if not judge1:
                os.makedirs(folder)
                logging.info('Folder %s creation success' % folder)
            else:
                logging.info('Folders %s already exist' % folder)
            conf = folder + '%s.conf' % nsp_port
            pid = folder + '%s.pid' % nsp_port
            data = '''
no-hosts
no-resolv
interface=%s
dhcp-lease-max=256
leasefile-ro
except-interface=lo
bind-interfaces
log-facility=/tmp/dnsmasq.log
log-async=10
dhcp-option=6,159.226.8.7,114.114.114.114
            ''' % nsp_port
            i = 0
            dhcpsum = ""
            for instance in linkto_list:
                if instance[0].gateway == 'default' or instance[0].gateway is "":
                    dhcp = """
dhcp-range=set:tag%d,%s,%s,%s,infinite
dhcp-host=%s,%s
dhcp-option=tag:tag%d,option:router
                    """ % (i, instance[0].ip, instance[0].ip, instance[0].mask, instance[0].mac, instance[0].ip, i)
                    logging.info(dhcp)
                else:
                    dhcp = """
dhcp-range=set:tag%d,%s,%s,%s,infinite
dhcp-host=%s,%s
dhcp-option=tag:tag%d,option:router,%s
                """ % (i, instance[0].ip, instance[0].ip, instance[0].mask, instance[0].mac, instance[0].ip, i, instance[0].gateway)
                i += 1
                dhcpsum = dhcpsum + dhcp
            confstr = data + dhcpsum
            with open(conf, 'w') as f:
                f.write(confstr)
            dhcppathlist = os.popen('which dnsmasq').readlines()
            dhcppath = dhcppathlist[0].split('\n')[0]
            cmd = "ip netns exec %s %s --dhcp-leasefile=%s --conf-file=%s" % (nsp_name,dhcppath, pid, conf)
            logging.info("%s" % cmd)
            os.popen(cmd)
            return 0
        except Exception, e:
            logging.error("%s:%s" % (Exception, e))
            return -1


    def close_dhcp_server(self):
        try:
            cmd = 'ps aux | pidof dnsmasq | xargs kill -9'
            os.system(cmd)
            return 0
        except Exception, e:
            logging.error("error:cmd error")
            return -1