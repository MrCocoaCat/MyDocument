# -*-coding:utf-8-*-
import sys
import os
from msgexecutor.msgsend import MQSender
from logger.logger import *
import json
from json import *

class FeedBack(object):

    __sender = None

    def __init__(self):
        self.sender = self.get_obj()
        self.taskid = ""
        self.name = ""
        self.server_ip = ""
        self.conclusion = 1
        self.emessage = ""
        self.need = 1
        self.done = 1

    @staticmethod
    def get_obj():
        if FeedBack.__sender is None:
            FeedBack.__sender = MQSender("192.168.122.234",61613)
        return FeedBack.__sender

    def jsontostr(self):
        msgstr = {"taskid":self.taskid,"name":self.name,"type":"F","server_ip":self.server_ip,
                  "result":{"conclusion":self.conclusion,"need":self.need,"done":self.done,"eno":0,"emessage":self.emessage}}
        res = json.dumps(msgstr)
        return res




    def feed_back(self, topic):
        resmsg = self.jsontostr()
        try:
            print resmsg
            self.sender.send_msg(topic,resmsg)
        except Exception, e:
            logging.error("Can not send the message %s" % (e) )

