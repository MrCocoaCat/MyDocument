# -*-coding:utf-8-*-
class NodeType(object):
    def __init__(self):
        self.VHOST = 1
        self.COM_ROUTER = 2
        self.COM_IDS = 4
        self.COM_IPS = 8
        self.COM_FW = 16
        self.SPE_ROUTER = 32
        self.SPE_IDS = 64
        self.SPE_IPS = 128
        self.SPE_FW = 256



class UsingType(object):

    #管理，内网，外网，镜像监控，1,2,4,8
    def __init__(self):
        pass


class CaseData(object):
    def __init__(self):
        self.switch_dict = {}
        self.hid_switch_dict = {}
        self.virhost_dict = {}
        self.router_dict = {}
        self.ips_dict = {}
        self.ids_dict ={}
        self.firewall_dict = {}
        self.subnet_dict = {}


class EmuInterface(object):
    def __init__(self):
        self.ip = ""
        self.mac = ""
        self.mask = ""
        self.gateway = ""
        self.boundary = ""
        self.is_boundary = False
        self.usage_type = 1
        self.id = 0
        self.Switch = None
        self.p_eth = ""
        self.link_type = ""


class Guest(object):
    def __init__(self):
        self.id = 0
        self.caseId = ""
        self.hypervisor = ""
        self.name = ""
        self.memory_size = 0   #单位MB
        self.vcpu_no = 0
        self.interface_list = [] # define class
        self.diskFile = ""
        self.osType = ""
        self.ImgSrcType = "" #暂时为空
        self.templateFile = "" #查询数据库
        self.templateId = 0
        self.vncIp = ""
        self.vncPort = 0
        self.nodeBName = ""
        self.diskimgFile = ""
        self.realTemplateId = 0


class Router(Guest):
    def __init__(self):
        super(Router, self).__init__()
        self.emutype = ""
        # self.template_id = 0


class Ips(Guest):
    def __init__(self):
        super(Ips, self).__init__()
        self.rules = []


class Firewall(Guest):
    def __init__(self):
        super(Firewall, self).__init__()
        self.rules = []
        self.portFilter = []


class Switch(object):
    def __init__(self):
        # 边界网卡信息
        self.boundary_interface_list = []
        # 存switch_id
        self.linkto_emu_switch_list = []
        self.ovsbr_name = ""
        self.nic_number = 0
        self.id = 0
        self.name = ""
        self.hypervisor = ""
        self.interface_list = []
        #self.linkto_interface_list = [] #(EmuInterface_Object, need_DHCP_ip)


class Ids(Guest):
    def __init__(self):
        super(Ids, self).__init__()
        self.rules = []



class FileTransferEntity():
    def __init__(self):
        self.isUpload = ""
        self.nodeId = ""
        self.hostFile = ""
        self.tempImgDstFile4Upload = ""




