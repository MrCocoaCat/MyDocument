# -*-coding:utf-8-*-
import sys
import os
from msgexecutor.msgsend import MQSender
from logger.logger import *
import json
from json import *
from conf.config import ConfParser


class HeartBack(object):

    __sender = None

    def __init__(self):
        self.sender = self.get_obj()
        self.id = 1
        self.ipaddr = ""
        self.name = ""

    @staticmethod
    def get_obj():
        if HeartBack.__sender is None:
            conf = ConfParser()
            MQIP = conf.get("MQ", "MQServerip")
            HeartBack.__sender = MQSender(MQIP,61613)
        return HeartBack.__sender

    def jsontostr(self):
        msgstr = {"id":self.id,"ipaddr":self.ipaddr,"name":self.name,"type":"emu"}
        res = json.dumps(msgstr)
        return res




    def feed_back(self, topic):
        resmsg = self.jsontostr()
        try:
            self.sender.send_msg(topic,resmsg)
        except Exception, e:
            logging.error("Can not send the message %s" % (e) )