.. Stomp documentation master file, created by
   sphinx-quickstart on Sun Sep 20 16:35:36 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Stomp.py |release| documentation
================================

Stomp.py was created by `Jason R Briggs <http://jasonrbriggs.com>`_. You can view outstanding issues, and find further info, on the `Github project page <http://github.com/jasonrbriggs/stomp.py>`_.

Contents:

.. toctree::
    :maxdepth: 2

    quickstart
    intro
    api
    commandline


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

